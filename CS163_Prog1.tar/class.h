#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

//Anteny Erdman, Program 1, CS163, 4/15/19
//This file will contain two structs and a class that will hold the functions being used.


//This struct will be used for any item that is placed into a category.
struct list
{
	char * item = NULL;
       	list * future = NULL;
};

//This struct will be used for any category.
struct category
{
	char * title = NULL;
	category * next = NULL;
	list * first = NULL;
	list * last = NULL;
};

//This class will be the foundation for the ADT so that main will not be able to access the structs
class creation
{
public:
	creation();
	~creation();
	int addCategory(char * newName);
	int addItem(char * newName, char * categoryName);
	int editLocation(char * itemName, char * categoryName, int location);
	int removeCategory(char * categoryName);
	int displayAll();
	int displayCategory(char * categoryName);
private:
	int addRecursive(char * newName, category * &head);
	category * head;
	category * tail;
};
