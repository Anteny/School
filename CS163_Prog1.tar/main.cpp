#include "class.h"

//Anteny Erdman, CS163, 4/17/19
//This file will include the main function

int main()
{
	creation mylist;
	//This will let people make choices.
	char happy = 'n';
	//This will let me know if the functions succeeded or failed.
	int success = 0;
	//This will let me know the position the user wants for the edit function
	int location = 0;

	//This portion of the code will be used to add categories.
	cout << "Would you like to add a category? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100,'\n');
	while(happy == 'Y' || happy == 'y')
	{
		char name [100];
		cout << "What would you like the category to be called?" << endl;
		cin.get(name, 100, '\n');
		cin.ignore(100, '\n');
		char * newName = new char[strlen(name) + 1];
		strcpy(newName, name);
		success = mylist.addCategory(newName);
		if(success == 0)
		{
			cout << "The category could not be added." << endl;
		}
		else
		{
			cout << "The category was added." << endl;
		}
		cout << "Would you like to add another category? (Y/N)" << endl;
		cin >> happy;
		cin.ignore(100, '\n');
		delete [] newName;
	}

	//This section will focus on adding new items to the categories.
	cout << "Would you like to add an item to a category? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100, '\n');
	while(happy == 'Y' || happy == 'y')
	{
		char name [100];
		cout << "What is the item?" << endl;
		cin.get(name, 100, '\n');
		cin.ignore(100, '\n');
		char * newName = new char [strlen(name) + 1];
		strcpy(newName, name);
		cout << "What is the name of the category you would like to add the item to?" << endl;
		cin.get(name, 100, '\n');
		cin.ignore(100, '\n');
		char * categoryName = new char [strlen(name) + 1];
		strcpy(categoryName, name);
		success = mylist.addItem(newName, categoryName);
		if(success == 0)
		{
			cout << "The item could not be added" << endl;
		}
		else
		{
			cout << "The item was added" << endl;
		}
		cout << "Would you like to add another item? (Y/N)" << endl;
		cin >> happy;
		cin.ignore(100, '\n');
		delete [] newName;
		delete [] categoryName;
	}

	//This portion of the code will have the user edit the location of an item inside of a category.
	cout << "Would you like to edit the location of an item? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100,'\n');
	while(happy == 'Y' || happy == 'y')
	{
		char name [100];
		cout << "What is the name of the item you would like to move?" << endl;
		cin.get(name, 100, '\n');
		cin.ignore(100, '\n');
		char * itemName = new char [strlen(name) + 1];
		strcpy(itemName, name);
		cout << "What is the name of the category the item is in?" << endl;
		cin.get(name, 100, '\n');
		cin.ignore(100, '\n');
		char * categoryName = new char [strlen(name) + 1];
		strcpy(categoryName, name);
		cout << "What is the number for the position you would like to move the item to?" << endl;
		cin >> location;
		cin.ignore(100, '\n');
		success = mylist.editLocation(itemName, categoryName, location);
		if(success == 0)
		{
			cout << "The item could not be moved." << endl;
		}
		else
		{
			cout << "The item was moved." << endl;
		}
		cout << "Would you like to move another item? (Y/N)" << endl;
		cin >> happy;
		cin.ignore(100, '\n');
		delete [] itemName;
		delete [] categoryName;
	}

	//This portion will focus on the removal of one category.
	cout << "Would you like to remove a category? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100, '\n');
	while(happy == 'Y' || happy == 'y')
	{
		char name [100];
		cout << "What category would you like to remove?" << endl;
		cin.get(name, 100, '\n');
		char * categoryName = new char[strlen(name) + 1];
	        strcpy(categoryName, name);
		success = mylist.removeCategory(categoryName);
		if(success == 0)
		{
			cout << "The category couldn't be removed" << endl;
		}
		else
		{
			cout << "The category was removed" << endl;
		}
		cout << "Would you like to remove another category? (Y/N)" << endl;
		cin >> happy;
		cin.ignore(100, '\n');
		delete [] categoryName;
	}

	//This portion will focus on only displaying one category.
	cout<< "Would you like to display a category? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100, '\n');
	while(happy == 'Y' || happy == 'y')
	{
		char name [100];
		cout << "What is the name of the category you would like to display?" << endl;
		cin.get(name, 100, '\n');
		cin.ignore(100, '\n');
		char * categoryName = new char[strlen(name) + 1];
		strcpy(categoryName, name);
		success = mylist.displayCategory(categoryName);
		if(success == 0)
		{
			cout << "Nothing could be displayed" << endl;
		}
		cout << "Would you like to display another category? (Y/N)" << endl;
		cin >> happy;
		cin.ignore(100, '\n');
		delete [] categoryName;
	}

	//This portion of the code will display everything.
	cout << "Would you like to display everything? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100, '\n');
	if(happy == 'Y' || happy == 'y')
	{
		success = mylist.displayAll();
		if(success == 0)
		{
			cout << "Nothing could be displayed." << endl;
		}
	}

	return 0;
}
