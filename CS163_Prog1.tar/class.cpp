#include "class.h"

//Anteny Erdman, CS163, 4/17/19
//This file will contain all of the functions other then main

//This function will initialize all of the private members.
creation::creation()
{
	head = NULL;
	tail = NULL;
}

//This function is a wrapper function for the recursive add category function
int creation::addCategory(char * newName)
{
	return addRecursive(newName, head);
}

//This function will use recursion to add a category.
int creation::addRecursive(char * newName, category * &head)
{
	int i = 0;
	int len = (strlen(newName) + 1);
	if(!head)
	{
		head = new category;
		head->title = new char[len];
		strcpy(head->title, newName);
		tail = head;
		return 1;
	}
	if(strcmp(newName, head->title) <= 0)
	{
		while(strcmp(newName, head->title) <= 0 && i < len)
		{
			if(strcmp(newName, head->title) < 0)
			{
				category * temp = head;
				head = new category;
				head->next = temp;
				head->title = new char[len];
				strcpy(head->title,newName);
				tail = temp;
				return 1;
			}
			++ i;
		}
		return 0;
	}
	return addRecursive(newName, head->next);
}

//This function will display all categories and items.
int creation::displayAll()
{
	category * current = head;
	list * display = NULL;
	if(!head)
	{
		return 0;
	}
	while(current)
	{
		cout << current->title << endl << endl;
		display = current->first;
		while(display)
		{
			cout << display->item << endl;
			display = display->future;
		}
		current = current->next;
	}
	return 1;
}

//This function will be used to edit the location of items in a category.
int creation::editLocation(char * itemName, char * categoryName, int location)
{
	list * temp = NULL;
	category * current = head;
	if(!head)
	{
		return 0;
	}
	while(strcmp(categoryName, current->title) != 0 && current->next)
	{
		current = current->next;
	}
	if(strcmp(categoryName, current->title) != 0)
	{
		return 0;
	}
	int pos = 1;
	list * now = current->first;
	if(strcmp(itemName, now->item) == 0)
	{
		temp = now;
		now = temp->future;
		current->first = now;
	}
	else
	{
		while(strcmp(itemName, now->future->item) != 0 && now->future->future)
		{
			now = now->future;
		}
		if(strcmp(itemName, now->future->item) != 0)
		{
			return 0;
		}
	
		temp = now->future;
		if(temp == current->last)
		{
			now->future = NULL;
			current->last = now;
		}
		else
		{
			now->future = temp->future;
	
		}
	}
	now = current->first;
	if(location == 1)
	{
		temp->future = now;
		current->first = temp;
	}
	++pos;
	while(pos != location && now->future)
	{
		now = now->future;
		++pos;
	}
	temp->future = now->future;
	now->future = temp;
	return 1;
}

//This function will be used to remove a singel category.
int creation::removeCategory(char * categoryName)
{
	list * temp = NULL;
	category * current = head;
	if(!head)
	{
		return 0;
	}
	if(strcmp(head->title, categoryName) == 0)
	{
		while(head->first)
		{
			temp = head->first->future;
			delete [] head->first->item;
			delete head->first;
			head->first = temp;
		}
		current = head->next;
		delete [] head->title;
		delete head;
		head = current;
		return 1;
	}
	while(strcmp(current->next->title, categoryName) != 0 && current->next)
	{
		current = current->next;
	}
	if(strcmp(current->next->title, categoryName) != 0)
	{
		return 0;
	}
	while(current->first)
	{
		temp = current->first->future;
		delete [] current->first->item;
		delete current->first;
		current->first = temp;
	}
	category * hold = current->next;
	current->next = hold->next;
	delete [] hold->title;
	hold = NULL;
	return 1;
}

//This function is used to display only one category.
int creation::displayCategory(char *categoryName)
{
	if(!head)
	{
		return 0;
	}
	category * current = head;
	while(strcmp(categoryName, current->title) != 0 && current->next)
	{
		current = current->next;
	}
	if(strcmp(categoryName, current->title) != 0)
	{
		return 0;
	}
	if(!current->first)
	{
		return 0;
	}
	list * display = current->first;
	while(display)
	{
		cout << display->item << endl;
		display = display->future;
	}
	return 1;
}

//This function will be used to add items to the categories.
int creation::addItem(char * newName, char * categoryName)
{
	category * current = head;
	if(!head)
	{
		return 0;
	}
	while(strcmp(categoryName, current->title) != 0 && current->next)
	{
		current = current->next;
	}
	if(strcmp(categoryName, current->title) == 0)
	{
		int len = (strlen(newName) + 1);
		if(current->first == NULL)
		{
			current->first = new list;
			current->first->item = new char[len];
			strcpy(current->first->item, newName);
			current->last = current->first;
			return 1;
		}
		current->last->future = new list;
		current->last = current->last->future;
		current->last->item = new char[len];
		strcpy(current->last->item, newName);
		return 1;
	}
	return 0;
}

//This function will deallocate all of the dynamically allocated memory used by the class.
creation::~creation()
{
	category * current = head;
	list * temp = NULL;
	while(head)
	{
		while(head->first)
		{
			temp = head->first->future;
			delete head->first->item;
			delete head->first;
			head->first = temp;
		}
		current = head->next;
		delete [] head->title;
		delete head;
		head = current;
	}
}
