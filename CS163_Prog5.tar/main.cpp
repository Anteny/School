//Anteny Erdman
//CS163
//This file will contain the main that will be used to call all the functions built in the class.cpp file

#include "class.h"

int main()
{
	list game;
	int success = game.create_edge(0, 1);
	success += game.create_edge(0, 2);
	success += game.create_edge(2, 3);
	success += game.create_edge(2, 4);
	success += game.create_edge(4, 5);
	success += game.create_edge(4, 6);
	success += game.create_edge(6, 7);
	success += game.create_edge(6, 8);
	success += game.create_edge(8, 9);
	success += game.create_edge(8, 10);
	char message[300] = "You are now embarking on a scavanger hunt for a pot of gold. Only one path leads to the treasure. Good Luck. Press 1 to go right down to a pond. Press 2 to go left to cross a bridge above the pond.";
	success += game.message(message, 0);
	char message1[300] = "You go down to the pond and get gobbled up by a flamingo. You Lose.";
	success += game.message(message1, 1);
	char message2[300] = "As you cross the bridge you see the flock of rabid flamingos attacking anything tht goes near the edge of the pond. Press 2 to go right off the bridge into the forest. Press 1 to follow the path.";
	success += game.message(message2, 2);
	char message3[300] = "After you cross the brush of the forest you see that somebody coverd up the original path. Press 2 to continue on the new path. Press 1 to head into the thicker part of the forest.";
	success += game.message(message3, 4);
	char message4[300] = "You continue on the path and soon it disappears. You become lost and cannot find your way home. You Lose.";
	success += game.message(message4, 3);
	char message5[300] = "You continue on the path and leave the jungle behind you. You enter an area of long rolling hills. Press 1 to start frolic over the hills. Press 2 to continue down the path.";
	success += game.message(message5, 6);
	char message6[300] = "You decide to leave the path in hopes that it was another fake. To bad for you a bundle of snakes are waiting for you. You Lose.";
	success += game.message(message6, 5);
	char message7[300] = "While you are froliccing along the hills you start stepping on slippery slime. That is when the hills swallow you whole. you Lose.";
	success += game.message(message7, 7);
	char message8[300] = "A little man is standing at the end of the path. He says he'll give you the treasure if you follow him. Press 1 to follow him. Press 2 to search on your own.";
	success += game.message(message8, 8);
	char message9[300] = "You follow the little man who leads you to a little shack. You go inside and he shoves you in the oven. You Lose.";
	success += game.message(message9, 9);
	char message10[300] = "You decide that the little man is to wierd for you. You look toward the sky for a sign and see a rainbow. You follow it and find the treasure. A gaint pot of gold. You Win!!";
	success += game.message(message10, 10);
	if(success == 21)
	{
		cout << "The game has been set." << endl;
	}
	char happy = 'Y';
	int choice = 0;
	while(happy == 'Y' || happy == 'y')
	{
		int pos = 0;
		while(pos != 1 && pos != 3 && pos != 5 && pos != 7 && pos != 9 && pos != 10)
		{
			if(game.display(pos) == 0)
			{
				cout << "The game has ran into an error." << endl;
			}
			cin >> choice;
			cin.ignore(100, '\n');
			pos = game.travel(choice, pos);
		}
		if(pos == 1 || pos == 3 || pos == 5 || pos == 7 || pos == 9 || pos == 10)
		{
			if(game.display(pos) == 0)
			{
				cout << "The game has ran into an error." << endl;
			}
		}
		cout << "Would you like to play again? (Y/N)" << endl;
		cin >> happy;
		cin.ignore(100, '\n');
	}
	return 0;
}
