//Anteny Erdman
//CS163
//This file will contain all of the functions that will be used in 
//the main.

#include "class.h"

//This is the constructor for the class
list::list()
{
	int success = create_list(11);
	if(success == 0)
	{
		a_list = NULL;
	}
}

//this is the destructor for the class
list::~list()
{
	vertex * temp = NULL;
	edge * ease = NULL;
	for(int i = 0; i < 11; ++i)
	{
		temp = a_list[i];
		while(temp->head)
		{
			ease = temp->head;
			if(ease->next)
			{
				temp->head = ease->next;
				delete ease->next;
				ease->next = NULL;
			}
			else
			{
				ease->next = NULL;
				temp->head = NULL;
			}
			if(ease)
			{
				delete ease;
			}
			ease = NULL;
		}
		temp->head = NULL;
		if(a_list[i]->pm)
		{
			delete [] a_list[i]->pm;
		}
		a_list[i]->pm = NULL;
		if(a_list[i])
		{
			delete a_list[i];
		}
		a_list[i] = NULL;
	}
	if(a_list)
	{
		delete [] a_list;
	}
	a_list = NULL;
}

//This is used to create the list
int list::create_list(int size)
{
	a_list = new vertex* [size];
	for(int i = 0; i < size; ++i)
	{
		a_list[i] = new vertex;
		a_list[i]->pm = NULL;
		a_list[i]->head = NULL;
		a_list[i]->num = i;
	}
	return 1;
}
		
//This function will be used to create the edge used that will be used for the choices
int list::create_edge(int from, int to)
{
	if(a_list[from]->head == NULL)
	{
		a_list[from]->head = new edge;
		edge * ease = a_list[from]->head;
		ease->next = NULL;
		ease->follow = a_list[to];
		return 1;
	}
	if(a_list[from]->head)
	{
		edge * ease = a_list[from]->head;
		ease->next = new edge;
		edge * hold = ease->next;
		hold->next = NULL;
		hold->follow = a_list[to];
		return 1;
	}
	return 0;
}

//This will be used to create the message the player sees when they traverse into the new vetex
int list::message(char * pm, int loc)
{
	int len = strlen(pm) + 1;
	a_list[loc]->pm = new char[len];
	strcpy(a_list[loc]->pm, pm);
	return 1;
}

//This function will be a wrapper function for the recursive 
int list::travel(int times, int pos)
{
	return travel((times - 1), a_list[pos]->head);
}

//this function will be used to recursively travel
int list::travel(int times, edge * choice)
{
	if(times == 0)
	{
		return choice->follow->num;
	}
	return travel((times - 1), choice->next);
}

//This will display the message in the vertex for the user
int list::display(int pos)
{
	cout << a_list[pos]->pm << endl;
	return 1;
}
