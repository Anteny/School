//Anteny Erdman
//CS163
//this file will contain the classes and prototypes for all functions used in the rest of the program.

#include <iostream>
#include <cstring>

using namespace std;

struct vertex
{
	struct edge * head;
	char * pm;
	int num;
};

struct edge
{
	edge * next;
	vertex * follow;
};

class list
{
	public:
		list();
		~list();
		int create_list(int size);
		int create_edge(int from, int to);
		int message(char * pm, int loc);
		int travel(int times, int pos);
		int display(int pos);
	private:
		vertex ** a_list;
		int travel(int times, edge * choice);
};

