#include <math.h>
#include <stdio.h>
#include <stdlib.h>


void setBits(unsigned int number, int temp, int frac, unsigned int *fnum, int exp, unsigned int *exnum, int *s);


float setFrac(int frac, unsigned int fnum);
