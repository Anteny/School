#include "extra.h"

int main()
{
    //All the numbers for the float equation.
    float M = 0;
    float E = 0;
    int s = 0;
    //exp is number of bits in the exponent field
    int exp = 0;
    int bias = 0;
    //frac is number of bits in the fraction field
    int frac = 0;
    unsigned int number = 0;
    int temp = 0;
    unsigned int fnum = 0;
    unsigned int exnum = 0;
    float fraction = 0.0;
    float final = 0.0;

    printf("Please enter the fraction bits\n");
    scanf("%d", &frac);
    printf("Please enter the number of exponent bits.\n");
    scanf("%d", &exp);
    printf("Please enter the hexadecimal representation of the number.\n");
    scanf("%x", &number);
    //these if statements check if the number are in range, and if sscanf worked.
    if(frac < 2 || frac > 10)
    {
        printf("The amount of fraction bits needs to be between 2 and 10.\n");
	printf("exiting!\n");
	return 0;
    }
    if(exp < 3 || exp > 5)
    {
        printf("The amount of exponent bits needs to be between 3 and 5.\n");
	printf("exiting!\n");
	return 0;
    }
    temp = ((int)log2(number) + 1);
    if(temp > (1 + exp + frac))
    {
        printf("The hexadecimal is larger then the amount of bits given.\n");
	printf("exiting!\n");
        return 0;
    }
    setBits(number, temp, frac, &fnum, exp, &exnum, &s);
    if(exnum != 0 && exnum != (pow(2, exp) - 1))
    {
        bias = (pow(2, (exp-1)) - 1);
        E = exnum - bias;
        fraction = setFrac(frac, fnum);
	M = 1 + fraction;
	final = (M * pow(2, E) * pow(-1, s));
    }
    else if(exnum == 0)
    {
        bias = (pow(2, (exp-1)) - 1);
        E = 1 - bias;
	M = setFrac(frac, fnum);
	final = (M * pow(2, E) * pow(-1, s));
	if(final == 0)
	{
            if(s == 1)
	    {
                printf("%f\n", final);
		return 0;
	    }
	}   
    }
    else
    {
        if(fnum == 0)
	{
            if(s == 1)
	    {
                printf("-∞\n");
		return 0;
	    }
	    else
	    {
                printf("∞\n");
                return 0;
	    }
	}
	else
	{
            printf("NaN\n");
	    return 0;
	}
    }
    printf("%f\n", final);
    return 0;
}
