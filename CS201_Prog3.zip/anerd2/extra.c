#include "extra.h"

void setBits(unsigned int number, int temp, int frac, unsigned int *fnum, int exp, unsigned int *exnum, int *s)
{
    int i = 0;
    int fflag = 0;
    int fcount = 0;
    int eflag = 0;
    int ecount = 0;

    while(i <= temp)
    {
        if(fflag == 0)
	{
            if(fcount < frac)
	    {
		if(number & (1 << i))
		{
                    *fnum |= 1 << fcount;
		}
		++fcount;
		++i;
	    }
	    else
	    {
                fflag = 1;
	    }
	}
	else if (eflag == 0)
	{
            if(ecount < exp)
	    {
		if(number & (1 << i))
		{
                    *exnum |= 1 << ecount;
		}
		++ecount;
		++i;
	    }
	    else
	    {
                eflag = 1;
	    }
	}
	else
	{
	    if(number & (1 << i))
	    {
                *s = 1;
	    }
	    ++i;
	}

    }
    return;
}

float setFrac(int frac, unsigned int fnum)
{
    float fraction = 0;
    int i = 1;
    while(frac > 0)
    {
        if(fnum & (1 << (frac - 1)))
	{
            fraction += (1/pow(2, i));
	}
	--frac;
	++i;
    }
    return fraction;
}
