//Anteny Erdman
//CS202
//Program 1
//This file will be used to build the prototypes of the classes that are used in the background. It will include the grades class,
// and the node classes if I am unable to figure out how to combine them with my other classes.

#include <iostream>
#include <cstring>


using namespace std;

//This class will hold and modify the grade for any of the assignment type classes that will be its children.
class grade
{
	public:
		//this function will initialize the private data members to their NULL equivilent values.
		grade();
		//This function will allow the user to see their final grade on the assignment.
		void display();
		//this function will allow the a person to set the weight of the grade.
		void set(int new_value);
		//This function will calulate the percentage that the user has gotten on the assingment and outputs the letter grade.
		void percentage(int new_value);
		//This function will allow the user to change the Final grade without needing to calculate the percentage again.
		void change(char final_grade);

		
	private:
		//This will hold the weight of the grade.
		int value;
		//This will be the final letter grade the student got on the assignment.
		char Final;
};
