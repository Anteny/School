//Anteny Erdman
//CS202
//This file will be used to hold the node classes.

#include "materials.h"

//This class will be used to have multiple chat rooms.
class nodeC: public chat
{
	public: 
		//this function will be used to set private members
		nodeC();
		//This will be used to deallocate dynamic members.
		~nodeC();
		//This will allow traversal
		nodeC *& go_next();
		//this will allow for the creation of next.
		void connect(nodeC * next);
		//This will delete the pointer
		void remove();

	private:
		//This is a pointer to the next node in the chain.
		nodeC * next;
		
};

//this class will allow for traversal of multiple homework assignments.
class nodeH: public homework
{
	public: 
		//this function will be used to set private members
		nodeH();
		//This will be used to deallocate dynamic members.
		~nodeH();
		//This will allow traversal
		nodeH *& go_next();
		//this will allow for the creation of next.
		void connect(nodeH * next);
		//This will delete the pointer
		void remove();

	private:
		//This is a pointer to the next node in the chain.
		nodeH * next;

};

//this class will allow for multiple videos.
class nodeV: public video
{
	public: 
		//this function will be used to set private members
		nodeV();
		//This will be used to deallocate dynamic members.
		~nodeV();
		//This will allow traversal
		nodeV *& go_next();
		//this will allow for the creation of next.
		void connect(nodeV * next);
		//This will delete the pointer
		void remove();
	
	private:
		//This is a pointer to the next node in the chain.
		nodeV * next;

};

//This class will allow for traversal and creation of multiple classes.
class lead
{
	public:
		//This will set th eprivate members
		lead();
		//This will deallocate dynamic memory
		~lead();
		//This will be a wrapper function to access the recursiv functions.
		void display_all(int assignment);
		//This will be a wrapper function to access the recursiv functions.
		void connect(int assignment);
		//This will be a wrapper funtion to access the recursive funtions.
		void remove_all(int assignment);
		//this wrapper function will allow acces to the grad set function
		void set(int assignment, int new_value);
		//This wrapper function will allow access to the grade percentage
		void percentage(int assignment, int new_value);
		//This wrapper function will allow access to the grade change function
		void change(int assignment, char final_grade);
		//This will be a wrapper function for the video play
		void play();
		//This will be a wrapper for the video create
		void createV(char * new_description, char * new_title);
		//This will be the wrapper for the homework create function
		void create(char * new_description, char * new_due, bool new_access);
		//this will be a wrapper for the homework change function
		void change(char * new_description, char * new_due, bool new_access);
		//This will be a wrapper for the chat create function
		void createC(char * new_name, char * new_user);
		//This will be a wrapper for the chat message function
		void message(char * new_message);
		//This function is used as a wrapper for the raise hand chat function
		void raise_hand();	
		//This will be the wrapper for the submit function.
		void submit();

	protected:
		//This will recursivly display all chat groups
		void display_all(nodeC *& head);
		//This will allow creation of new files.
		void connect(nodeC *& head, nodeC * new_member);
		//This will recursivly delete all chat groups
		void remove_all(nodeC *& head);		
		//This will recursivly display all video groups
		void display_all(nodeV *& head);
		//This will allow creation of new files.
		void connect(nodeV *& head, nodeV * new_member);
		//This will recursivly delete all video groups	
		void remove_all(nodeV *& head);
		//This will recursivly display all homework groups
		void display_all(nodeH *& head);
		//This will allow creation of new files.
		void connect(nodeH *& head, nodeH * new_member);
		//This will recursivly delete all homework groups
		void remove_all(nodeH *& head);
		//This will allow a start to the chat linked list
		nodeC * headC;
		//This will allow a start to the homework linked list
		nodeH * headH;
		//this will allow a start to the video linked list
		nodeV * headV;
};
