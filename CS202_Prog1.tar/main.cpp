//Anteny Erdman
//CS202
//Prog 1
//This file will be used as a manager for the other functions created in the .cpp files and .h files. 
//It will be the glue that holds together the program.

#include "node.h"
	
int main()
{
	
	int size = 100;
	int types = 3;
	int choice = 1;
	char * name = new char[size];
	char * des = new char[size];
	bool access = false;
	lead * classes = new lead [types];
	while(choice == 1)
	{
		cout << "Press 1 if you would like to work with homework." << endl;
		cout << "Press 2 if you would like to work with video assignments." << endl;
		cout << "Press 3 if you would like to work with chat rooms." << endl;
		cin >> choice;
		cin.ignore(100, '\n');
		if(choice == 1)
		{
			while(choice == 1)
			{
				cout << "Press 1 to create a new homework assignment." << endl;
				cout << "Press 2 to change an assignment." << endl;
				cout << "Press 3 to clear the assignments." << endl;
				cout << "Press 4 to mark the assignment as completed." << endl;
				cin >> choice;
				cin.ignore(100, '\n');
				if(choice == 1)
				{
					cout << "Please enter the description and due date for the item." << endl;
					cin.get(des, 100, '\n');
					cin.ignore(100, '\n');
					cin.get(name, 100, '\n');
					cin.ignore(100, '\n');
					cout << "Press 1 if you would like to allow access to the assignment." << endl;
					cin >> choice;
					cin.ignore(100, '\n');
					if(choice == 1)
					{
						access = true;
					}
					else 
					{
						access = false;
					}
					classes[0].create(des, name, access);				
				}
				else if(choice == 2)
				{	
					cout << "Please enter the description and due date for the item." << endl;
					cin.get(des, 100, '\n');
					cin.ignore(100, '\n');
					cin.get(name, 100, '\n');
					cin.ignore(100, '\n');
					cout << "Press 1 if you would like to allow access to the assignment." << endl;
					cin >> choice;
					cin.ignore(100, '\n');
					if(choice == 1)
					{
						access = true;
					}
					else 
					{
						access = false;
					}
					classes[0].change(des, name, access);
				}
				else if(choice == 3)
				{
					classes[0].remove_all(1);
				}
				else
				{
					classes[0].submit();
				}
				cout << "If you would like to continue working with the homework assignments press 1. Otherwise press 4." << endl;
				cin >> choice;
				cin.ignore(100, '\n');
			}

		}
		else if(choice == 2)
		{
			while(choice == 2)
			{
				cout << "Press 1 to create a new video." << endl;
				cout << "Press 2 to play a video." << endl;
				cout << "Press 3 to delete videos." << endl;
				cin >> choice;
				cin.ignore(100, '\n');
				if(choice == 1)
				{
					cout << "Plese enter the description of the video and then the title for the video." << endl;
					cin.get(des, 100 ,'\n');
					cin.ignore(100, '\n');
					cin.get(name, 100, '\n');
					cin.ignore(100, '\n');
					classes[1].createV(des, name);
				}
				else if(choice == 2)
				{
					classes[1].play();
				}
				else
				{
					classes[1].remove_all(2);
				}
				cout << "If you would like to continue working with videos please press 2. otherwise press 4." << endl;
			}
		}
		else
		{
			while (choice == 3)
			{
				cout << "Press 1 to create a new chat room." << endl;
				cout << "Press 2 to raise your hand." << endl;
				cout << "Press 3 to clear chat rooms." << endl;
				cout << "Press 4 to send a new message." << endl;
				cin >> choice;
				cin.ignore(100, '\n');
				if(choice == 1)
				{
					cout << "please enter the name of the chat room then your user name." << endl;
					cin.get(des, 100, '\n');
					cin.ignore(100, '\n');
					cin.get(name, 100, '\n');
					cin.ignore(100, '\n');
					classes[2].createC(des, name);
				}
				else if(choice == 2)
				{
					classes[2].raise_hand();
				}
				else if(choice == 3)
				{
					classes[2].remove_all(3);
				}
				else
				{
					cout << "Please enter your message." << endl;
					cin.get(des, 100, '\n');
					cin.ignore(100, '\n');
					classes[2].message(des);
				}
				cout << "If you would like to continue working with chat please press 3. Otherwise press 4." << endl;
			}
		}
		cout << "Press 1 if you would like to continue." << endl;
		cin >> choice;
		cin.ignore(100, '\n');
	}
	classes[0].remove_all(1);
	classes[1].remove_all(2);
	classes[2].remove_all(3);
	delete[] classes;
	delete[] des;
	delete[] name;
	return 0;
}
