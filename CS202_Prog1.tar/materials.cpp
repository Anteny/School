//Anteny Erdman
//CS202
//This file will be used to implement all of the classes created in the materials.h file.

#include "node.h"

//This function sets the values of the data members to their NULL values.
video::video()
{
	title = NULL;
	description = NULL;
	flag = false;
}

//This function will be used if the video is copied.
video::video(const video &old_video): description(old_video.description), title(old_video.title), flag(old_video.flag)
{

}

//This function is used to deallocate dynamic memory.
video::~video()
{
	delete[] description;
	delete[] title;
}

//This function will be used to play the video stored.
void video::play()
{
	if(flag == false)
	{
		change_flag();
	}
	else
	{
		cout << "You have already seen this video." << endl;
	}
	display();
	
	cout << "The video is currently playing" << endl;
	return;
}

//this function will be used to change the flag.
void video::change_flag()
{
	if(flag == false)
	{
		flag = true;
	}
	else
	{
		flag = false;
	}
	return;
}

//This function will be used to create a new video
void video::create(char * new_description, char * new_title)
{
	description = new char [strlen(new_description)+ 1];
	strcpy(description, new_description);
	title = new char [strlen(new_title) + 1];
	strcpy(title, new_title);
}

//This function will be used to display the information about a video.
void video::display()
{
	grade::display();
	cout << title << endl;
	cout << description << endl;
	return;
}

//This class will be used to delete the currently viewed video. This will allow the object to be changed.
void video::remove()
{
	delete[] description;
	description = NULL;
	delete[] title;
	title = NULL;
	flag = false;
	return;
}

//this function will be used to initilize the values of the chat class.
chat::chat()
{
	name = NULL;
	user = NULL;
	hand = false;
}
 
//This funtion will be used to avoid shallow copies of chat class.
chat::chat(const chat &original)
{
	name = new char[strlen(original.name) + 1];
	strcpy(name, original.name);
	user = new char[strlen(original.user) + 1];
	strcpy(user, original.user);
}

//this funtion will be used to deallocate memory of the chat class.
chat::~chat()
{
	delete[] name;
	delete[] user;
}

//This function will allow the user to display the information about the chat room
void chat::display()
{
	grade::display();
	cout << "The name of the chat room is '" << name << "'" << endl;
	cout << "The people in the group are ... " << endl;
	cout << user << endl;
	return;
}

//This function will allow a new chat room to be created.
void chat::create(char * new_name, char * new_user)
{

	name = new char[strlen(new_name) + 1];
	strcpy(name, new_name);
	user = new char[strlen(new_user) + 1];
	strcpy(user, new_user);
	return;
}

//This will allow the user to clear all information from a chat room
void chat::remove()
{
	name = NULL;
	delete name;
	user = NULL;
	delete user;
	return;
}

//This function will allow the user to send a message to the chat room.
void chat::message(char * new_message)
{
	cout << name << endl;
	cout << user << ": " << new_message << endl << endl;
	return;
}

//This function will let people know you want to talk.
void chat::raise_hand()
{
	if(hand == false)
	{
		hand = true;
		cout << user << "'s hand is raised." << endl << endl;
	}
	else
	{
		hand = false;
		cout << user << " has put their hand down." << endl << endl;
	}
}

//this function will initalize the private data.
homework::homework()
{
	description = NULL;
	due = NULL;
	access = false;
	submission = false;
}

//This function will allow the user to avoid shallow copies.
homework::homework(const homework &original)
{

	due = new char[strlen(original.due) + 1];
	strcpy(due, original.due);
	description = new char[strlen(original.description) + 1];
	strcpy(description, original.description);
	access = original.access;
}

//This will deallocate any dynamic memory used in the class
homework::~homework()
{
	delete[] description;
	delete[] due;
}

//This will allow the user to see all the information about the assignment.
void homework::display()
{
	if(access == false)
	{
		cout << "You do not currently have access to this assignment." << endl;
		return;
	}
	cout << description << endl << endl;
	cout << "The assignment is due: " << due << endl;
	if(submission == false)
	{
		cout << "You have not yet turned in the assignment." << endl;
	}
	else
	{
		cout << "You have already turned in this assignment." <<endl;
	}
	grade::display();
	return;
}

//This function will create a new function
void homework::create(char * new_description, char * new_due, bool new_access)
{	
	due = new char[strlen(new_due) + 1];
	strcpy(due, new_due);
	description = new char[strlen(new_description) + 1];
	strcpy(description, new_description);
	access = new_access;
	return;
}

//This function will allow the user to change any part of the assignment
void homework::change(char * new_description, char * new_due, bool new_access)
{
	if(new_due)
	{
		due = NULL;
		delete due;
		due = new char[strlen(new_due) + 1];
		strcpy(due, new_due);
	}
	if(new_description)
	{
		description = NULL;
		delete description;
		description = new char[strlen(new_description) + 1];
		strcpy(description, new_description);
	}
	if(new_access)
	{
		access = new_access;
	}
	return;
}

//This function will allow the user to delete the information in an assignment.
void homework::remove()
{
	due = NULL;
	delete due;
	description = NULL;
	delete description;
	access = false;
	return;
}

//this function allows the user to show they have completed the assignment.
void homework::submit()
{
	if(access == true)
	{
		submission = true;
		return;
	}
	else
	{
		cout << "You do not have access to this assignment at this time. Please contact your instructor for further instruction." << endl;
		return;
	}
}

