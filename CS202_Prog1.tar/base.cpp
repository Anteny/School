//Anteny Erdman
//CS202
//Prog 1
//this file will be used for the implementation of any classes created in the base.h file.

#include "node.h"


//This class sets the private members to their zero equivelent values.
grade::grade()
{
	value = 0;
	Final = 'A';
}

//This function will be used in every assignment class to show off the grade that they recieve.
void grade::display()
{
	cout << "your grade on this assignment is " << Final << endl;
	return;
}

//this will let a person change the weight of the assignment whenver they need to.
void grade::set(int new_value)
{
	value = new_value;
	return;
}

//This class will calculate the percentage for the class and then output the letter grade.
void grade::percentage(int new_value)
{
	int percentage = ((new_value*100)/value);
	if(percentage >= 90)
	{
		change('A');
		return;
	}
	else if(percentage >= 80)
	{
		change('B');
		return;
	}
	else if(percentage >= 70)
	{
		change('C');
		return;
	}
	else if(percentage >= 60)
	{
		change('D');
		return;
	}
	else
	{
		change('F');
		return;
	}
}

//This function will be used to change the Final grade.
void grade::change(char final_grade)
{
	Final = final_grade;
	return;
}

//This function will be used to set the data for the nodes private member.
nodeC::nodeC()
{
	next = NULL;
}

//This function will be used deallocate dynamic data
nodeC::~nodeC()
{
	next = NULL;
	delete next;
}

//this function will be used to connect to a new node
void nodeC::connect(nodeC * cont)
{
	next = cont;
	return;
}

//This function will delete the dynamic memory.
void nodeC::remove()
{
	next = NULL;
	delete next;
	chat::remove();
	return;
}

//This function will allow for recursive traversal.
nodeC *& nodeC::go_next()
{
	return next;
}

//This function will be used to set the data for the nodes private member.
nodeH::nodeH()
{
	next = NULL;
}

//This function will be used deallocate dynamic data
nodeH::~nodeH()
{
	next = NULL;
	delete next;
}

//this function will be used to connect to a new node
void nodeH::connect(nodeH * cont)
{
	next = cont;
	return;
}

//This function will allow for recursive traversal.
nodeH *& nodeH::go_next()
{
	return next;
}

//This function will delete the dynamic memory.
void nodeH::remove()
{
	next = NULL;
	delete next;
	homework::remove();
	return;
}

//This function will be used to set the data for the nodes private member.
nodeV::nodeV()
{
	next = NULL;
}

//This function will be used deallocate dynamic data
nodeV::~nodeV()
{
	next = NULL;
	delete next;
}

//this function will be used to connect to a new node
void nodeV::connect(nodeV * cont)
{
	next = cont;
	return;
}

//This function will allow for recursive traversal.
nodeV *& nodeV::go_next()
{
	return next;
}

//This function will delete the dynamic memory.
void nodeV::remove()
{
	next = NULL;
	delete next;
	video::remove();
	return;
}

//this will set private variables.
lead::lead()
{
	headC = NULL;
	headV = NULL;
	headH = NULL;
}

//This will deallocate the memory used by this class
lead::~lead()
{
	delete headC;
	delete headV;
	delete headH;
}

//This function will recursivly call display for chat classes
void lead::display_all(nodeC *& head)
{
	if(!head)
	{
		return;
	}
	head->display();
	return display_all(head->go_next());
}

//This funciton will allow for he addition of new items.
void lead::connect(nodeC *& head, nodeC * new_member)
{
	if(!head)
	{
		return;
	}
	if(head->go_next())
	{
		connect(head->go_next(), new_member);
	}
	else 
	{
		head->connect(new_member);
	}
	return;
}

//This function will remove all dynamicly allocated memory.
void lead::remove_all(nodeC *& head)
{
	if(!head)
	{
		return;
	}
	else 
	{
		remove_all(head->go_next());
		head->nodeC::remove();
		return;
	}
}

//This function will recursivly call display for chat classes
void lead::display_all(nodeH *& head)
{
	if(!head)
	{
		return;
	}
	head->display();
	return display_all(head->go_next());
}

//This funciton will allow for he addition of new items.
void lead::connect(nodeH *& head, nodeH * new_member)
{
	if(!head)
	{
		return;
	}
	if(head->go_next())
	{
		connect(head->go_next(), new_member);
	}
	else 
	{
		head->connect(new_member);
	}
	return;
}

//This function will remove all dynamicly allocated memory.
void lead::remove_all(nodeH *& head)
{
	if(!head)
	{
		return;
	}
	else 
	{
		remove_all(head->go_next());
		head->nodeH::remove();
		return;
	}
}

//This function will recursivly call display for chat classes
void lead::display_all(nodeV *& head)
{
	if(!head)
	{
		return;
	}
	head->display();
	return display_all(head->go_next());
}

//This funciton will allow for he addition of new items.
void lead::connect(nodeV *& head, nodeV * new_member)
{
	if(!head)
	{
		return;
	}
	if(head->go_next())
	{
		connect(head->go_next(), new_member);
	}
	else 
	{
		head->connect(new_member);
	}
	return;
}

//This function will remove all dynamicly allocated memory.
void lead::remove_all(nodeV *& head)
{
	if(!head)
	{
		return;
	}
	else 
	{
		remove_all(head->go_next());
		head->nodeV::remove();
		return;
	}
}

//Thsi wrapper function will be used to access the display recursive function
void lead::display_all(int assignment)
{
	if(assignment == 1)
	{
		display_all(headH);
	}
	else if(assignment == 2)
	{
		display_all(headV);
	}
	else
	{
		display_all(headC);
	}
	return;
}

//This function will be used as a wrapper for the connect function
void lead::connect(int assignment)
{	
	if(assignment == 1)
	{	nodeH * temp = new nodeH;
		connect(headH, temp);
	}
	else if(assignment == 2)
	{	nodeV * temp = new nodeV;
		connect(headV, temp);
	}
	else
	{	nodeC * temp = new nodeC;
		connect(headC, temp);
	}
	return;
}

//this function will be a wrapper for the remove function
void lead::remove_all(int assignment)
{
	if(assignment == 1)
	{
		remove_all(headH);
		delete headH;
	}
	else if(assignment == 2)
	{
		remove_all(headV);
		delete headV;
	}
	else
	{
		remove_all(headC);
		delete headC;
	}
	return;
}

//this will be a wrapper for the grade set funtcion
void lead::set(int assignment, int new_value)
{
	if(assignment == 1)
	{
		headH->grade::set(new_value);
	}
	else if(assignment == 2)
	{
		headV->grade::set(new_value);
	}
	else
	{
		headC->grade::set(new_value);
	}
	return;
}

//Thsi will be a wrapper funtion for the grade percentage function
void lead::percentage(int assignment, int new_value)
{
	if(assignment == 1)
	{
		headH->grade::percentage(new_value);
	}
	else if(assignment == 2)
	{
		headV->grade::percentage(new_value);
	}
	else
	{
		headC->grade::percentage(new_value);
	}
	return;
}


//This wrapper function will allow access to the grade change function
void lead::change(int assignment, char final_grade)
{
	if(assignment == 1)
	{
		headH->grade::change(final_grade);
	}
	else if(assignment == 2)
	{
		headV->grade::change(final_grade);
	}
	else
	{
		headC->grade::change(final_grade);
	}
	return;
}

//This will be a wrapper for the video play
void lead::play()
{
	headV->play();
	return;
}

//this will be a wrapper function for the video create
void lead::createV(char * new_description, char * new_title)
{
	headV->create(new_description, new_title);
	return;
}

//This will be the wrapper for the homework create function
void lead::create(char * new_description, char * new_due, bool new_access)
{
	headH->create(new_description, new_due, new_access);
	return;
}

//This will be a wrapper for the homework change function
void lead::change(char * new_description, char * new_due, bool new_access)
{
	headH->change(new_description, new_due, new_access);
	return;
}

//this will be a wrapper for the chat create function
void lead::createC(char * new_name, char * new_user)
{
	headC->create(new_name, new_user);
	return;
}

//This will be a wrapper function for the chat message function
void lead::message(char * new_message)
{
	headC->message(new_message);
	return;
}

//This will be used as the chat raise hand wrapper
void lead::raise_hand()
{
	headC->raise_hand();
	return;
}

//this is the wrapper function for the submit function
void lead::submit()
{
	headH->submit();
	return;
}
