//Anteny Erdman
//CS202
//Program 1
//This file will be used to support the 3 most important classes in this program. The video lecture, the assignment, and the chat classes.
//The prototypes for the classes and their members will be created here.

#include "base.h"

//This class will be used to play homework videos.
class video: public grade
{
	public:
		//this will initilize the dynamic memory
		video();
		//this will be used to avoid shallow copies of the class.
		video(const video &old_video);
		//this will deallocate the dynamic memory
		~video();
		//This will be used to play the function.
		void play();
		//This will be used to switch the flag.
		void change_flag();
		//This will be used to create a new video.
		void create(char * new_description, char * new_title);
		//This function will be used to delete videos. 
		void remove();
		//This function will allow me to display the contents of the class.
		void display();

	private:
		//the description will hold the information about the video.
		char * description;
		//the title will be displayed to show what the video is.
		char * title;
		//the flag will be used to show if someone has seen the video or not.
		bool flag;

};

//This class will be used to display homework that needs to be done.
class homework: public grade
{
	public:
		//this will be used to initalize all the private members
		homework();
		//this will allow us to avoid shallow copies of the homework
		homework(const homework &original);
		//This will deallocate any dynamic memory
		~homework();
		//This function will display all the information about the assignment.
		void display();
		//This function will be used to create a new assignment.
		void create(char * new_description, char * new_due, bool new_access);
		//This will allow the user to change any part of the assignment.
		void change(char * new_description, char * new_due, bool new_access);
		//This will allow the user to delete an assignment.
		void remove();
		//This function will allow the user to mark the assignment as completed
		void submit();

	private:
		//This will explain what the students are expected to due.
		char * description;
		//this will show the students when the assignment is due.
		char * due;
		//this will allow the teacher to restrict access to the student.
		bool access;
		//this will show if the student completed the activity.
		bool submission;

	 
};


//This class will be used to interact with a "chat room"
class chat: public grade
{
	public:
		//This function will be used to initilize the private members of this class.
		chat();
		//This function will be used to avoid shallow copies of this class.
		chat(const chat &original);
		//This function will allow the dynamic memory to be deallocated.
		~chat();
		//This function will be used to display the information about the chat room.
		void display();
		//This will allow the user to create a new chat room.
		void create(char * new_name, char * new_user);
		//This function will be used to clear a room of any information.
		void remove();
		//This function is what the class is all about. The messages of the chat room.
		void message(char * new_message);
		//This function will be used to raise your hand
		void raise_hand();

	private:
		//this will be used as the name of the chat room
		char * name;
		//This will be used to show who said what
		char * user;
		//This will be used as a way to signal your hand is up
		bool hand;

};


