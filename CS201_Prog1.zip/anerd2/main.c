#include "ExtraFunc.h"

int main()
{
    int flag0 = 0;
    int flag1 = 0;
    int flag2 = 0;
    int flag3 = 0;
    int flag4 = 0;
    int flag5 = 0;
    int flag6 = 0;
    int flag7 = 0;
    int flag8 = 0;
    int flag9 = 0;
    char word[10];

    /*Uses the time of day to seed the random number generator used by rand()*/
    srand((unsigned) GetTimeMS());
    struct timeval start;
    start.tv_usec = GetTimeMS();
    start.tv_sec = GetTimeS();
    

    /*will call the check function using the generated word*/
    while(flag9 == 0)
    {
        int Random = rand() % 9;
        if(Random ==0)
	{
	    strcpy(word, "The");
            check(word);
	    flag0 = 1;
	}
        if(Random ==1)
	{
	    strcpy(word, "quick");
            check(word);
	    flag1 = 1;
	}
        if(Random ==2)
	{
	    strcpy(word, "brown");
            check(word);
	    flag2 = 1;
	}
        if(Random ==3)
	{
	    strcpy(word, "fox");
            check(word);
	    flag3 = 1;
	}
        if(Random ==4)
	{
	    strcpy(word, "jumps");
            check(word);
	    flag4 = 1;
	}
        if(Random ==5)
	{
	    strcpy(word, "over");
            check(word);
	    flag5 = 1;
	}
        if(Random ==6)
	{
	    strcpy(word, "the");
            check(word);
	    flag6 = 1;
	}
        if(Random ==7)
	{
	    strcpy(word, "lazy");
            check(word);
	    flag7 = 1;
	}
        if(Random ==8)
	{
	    strcpy(word, "dog");
            check(word);
	    flag8 = 1;
	}
	if(flag0 != 0)
	{
            if(flag1 != 0)
            {
                if(flag2 != 0)
	        {
                    if(flag3 != 0)
	            {
                        if(flag4 != 0)
	                {
                            if(flag5 != 0)
	                    {
                                if(flag6 != 0)
	                        {
                                    if(flag7 != 0)
	                            { 
                                        if(flag8 != 0)
	                                {
                                            flag9 = 1;
 	                                }	
	                            }	
	                        }	
	                    }	
	                }	
	            }	
	        }	
	    }	
        }
    }
    struct timeval end;
    end.tv_usec = GetTimeMS();
    end.tv_sec = GetTimeS();
    struct timeval res;
    timersub(&end, &start, &res);
    printf("It took you %ld seconds ", res.tv_sec);
    printf("and %ld microseconds \n", res.tv_usec);

    return 0;
}
