#include "ExtraFunc.h"

unsigned long GetTimeMS()
{
    /*returns the micorseconds of gettimeofday*/
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_usec;
}

unsigned long GetTimeS()
{
    /*returns the seconds of gettimeofday*/
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec;
}

void check(char word[])
{
    char c = 'a';
    char input[10];
    printf("Please type %s: ", word);
    scanf("%10s", input);
    while((c = getchar()) != '\n' && c != EOF);
    while(strcmp(input, word) != 0)
    {     
        printf("Please type %s: ", word);
        scanf("%s", input);
    }
    return;
}
