#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>

void check(char word[]);

unsigned long GetTimeS();

unsigned long GetTimeMS();
