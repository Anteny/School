//Anteny erdman
//CS202
//This file will be used to hold all information on the parent class.

#include <iostream>
#include <cstring>
using namespace std;

class link
{
	public:
		link();
		~link();
		link(const link &original);

	protected:
		char * title;
		char * des;
		char * source;
		int priority;
};
