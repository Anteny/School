//anteny Erdman
//cs202
//This file will be used to hold all members created in the base.h and node.h files.

#include "node.h"

link::link()
{
	des = NULL;
	source = NULL;
	title = NULL;
}

link::~link()
{
	des = NULL;
	delete [] des;
	source = NULL;
	delete [] source;
	title = NULL;
	delete [] source;
}

link::link(const link &original): des(original.des), source(original.source), title(original.title)
{

}

node::node()
{
	left = NULL;
	right = NULL;
	chat = NULL;
	station = NULL;
	site = NULL;
}

node::node(const node &original): left(original.left), right(original.right), chat(original.chat), station(original.station), site(original.site)
{
}

node::~node()
{
	delete left;
	delete right;
	delete chat;
	delete station;
	delete site;
	left = NULL;
	right = NULL;
	chat = NULL;
	station = NULL;
	site = NULL;
}

void node::connect_left(node * to_connect)
{
	left = to_connect;
	return;
}

void node::connect_right(node * to_connect)
{
	right = to_connect;
	return;
}

node* node::go_left()
{
	if(left)
	{
		return left;
	}
	else
	{
		return NULL;
	}
}

node* node::go_right()
{
	if(right)
	{
		return right;
	}
	else
	{
		return NULL;
	}
}

void node::create_zoom()
{
	cin >> chat;
	cin.ignore(100, '\n');
	return;
}
	
void node::create_news()
{
	cin >> station;
	cin.ignore(100, '\n');
	return;
}

void node::create_web()
{
	cin >> site;
	cin.ignore(100, '\n');
	return;
}

void node::display()
{
	if(chat)
	{
		cout << chat << endl;
	}
	if(station)
	{
		cout << station << endl;
	}
	if(site)
	{
		cout << site << endl;
	}
	return;
}

char* node::get_name(int choice)
{
	if(choice == 1)
	{
		return chat->get_name();
	}
	else if(choice == 2)
	{
		return station->get_name();
	}
	else
	{
		return site->get_name();
	}
}

list::list()
{
	root = NULL;
}

list::list(const list &original): root(original.root)
{

}

list::~list()
{
	delete root;
}

void list::add_item()
{
	if(!root)
	{
		root = new node;
		cout << "Press 1 if you would like to add a zoom link." << endl;
		cout << "Press 2 if you would like to add a news station." << endl;
		cout << "Press 3 if you would like to add a website." << endl;
		int choice = 0;
		cin >> choice;
		cin.ignore(10, '\n');
		if(choice == 1)
		{
			root->create_zoom();
		}
		else if(choice == 2)
		{
			root->create_news();
		}
		else
		{
			root->create_web();
		}
		return;
	}
	else
	{
		cout << "Press 1 if you would like to add a zoom link." << endl;
		cout << "Press 2 if you would like to add a news station." << endl;
		cout << "Press 3 if you would like to add a website." << endl;
		int choice = 0;
		cin >> choice;
		cin.ignore(10, '\n');
		return add_item(root, choice);
	}
}

void list::add_item(node * root, int choice)
{
	if(choice == 1)
	{
		if(!root->chat)
		{
			root->create_zoom();
			return;
		}
	}
	if(choice == 2)
	{
		if(!root->station)
		{
			root->create_news();
			return;
		}
	}
	if(choice == 3)
	{
		if(!root->site)
		{
			root->create_web();
			return;
		}
	}
	if(!root->go_left())
	{
		node * temp = new node;
		root->connect_left(temp);
		return add_item(root->go_left(), choice);
	}	
	else if(!root->go_right())
	{
		node * temp = new node;
		root->connect_right(temp);
		return add_item(root->go_right(), choice);
	}
	else
	{
		node * temp = new node;
		temp->connect_left(root->go_left());
		temp->connect_right(root->go_right());
		root->connect_right(temp);
		root->connect_left(NULL);
		return add_item(root->go_right(), choice);
	}
}

void list::remove_all()
{
	if(!root)
	{
		return;
	}
	else
	{
		return remove_all(root);
	}
}

void list::remove_all(node * root)
{
	if(root->go_left())
	{
		remove_all(root->go_left());
	}
	if(root->go_right())
	{
		remove_all(root->go_right());
	}
	delete root;
	root = NULL;
	return;
}

void list::display()
{
	if(!root)
	{
		return;
	}
	else
	{
		return display(root);
	}
}

void list::display(node * root)
{
	if(root->go_left())
	{
		display(root->go_left());
	}
	if(root->go_right())
	{
		display(root->go_right());
	}
	root->display();
	return;
}

zoom& list::retrievez()
{
	if(!root)
	{
		zoom temp;
		return temp;
	}
	else
	{
		char * temp = new char [100];
		cout << "What is the name of the zoom room you want retrieve." << endl;
		cin.get(temp, 100, '\n');
		cin.ignore(100, '\n');
		return retrievez(root, temp);
	}
}

zoom& list::retrievez(node* root, char* name)
{
	if(strcmp(name, root->get_name(1)) == 0)
	{
		return root->chat;
	}
	else if(root->go_left())
	{
		return retrievez(root->go_left(), name);
	}
	else if(root->go_right())
	{
		return retrievez(root->go_right(), name);
	}
	else
	{
		return NULL;
	}
}

news& list::retrieven()
{
	if(!root)
	{
		return NULL;
	}
	else
	{
		char * temp = new char [100];
		cout << "What is the name of the news station you want retrieve." << endl;
		cin.get(temp, 100, '\n');
		cin.ignore(100, '\n');
		return retrieven(root, temp);
	}
}

news& list::retrieven(node* root, char* name)
{
	if(strcmp(name, root->get_name(2)) == 0)
	{
		return root->station;
	}
	else if(root->go_left())
	{
		return retrieven(root->go_left(), name);
	}
	else if(root->go_right())
	{
		return retrieven(root->go_right(), name);
	}
	else
	{
		return NULL;
	}
}

website& list::retrievew()
{
	if(!root)
	{
		return NULL;
	}
	else
	{
		char * temp = new char [100];
		cout << "What is the name of the website you want retrieve." << endl;
		cin.get(temp, 100, '\n');
		cin.ignore(100, '\n');
		return retrievew(root, temp);
	}
}

website& list::retrievew(node* root, char* name)
{
	if(strcmp(name, root->get_name(3)) == 0)
	{
		return root->site;
	}
	else if(root->go_left())
	{
		return retrievew(root->go_left(), name);
	}
	else if(root->go_right())
	{
		return retrievew(root->go_right(), name);
	}
	else
	{
		return NULL;
	}
}
