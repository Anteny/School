//Anteny Erdman
//CS202
//THis file will be used to interact with all the other .cpps

#include "node.h"

int main()
{
	int choice = 0;
	list info;
	zoom chat;
	news station;
	website site;
	while(choice != 5)
	{
		cout << "Press 1 if you would like to add an item." << endl;
		cout << "Press 2 if you would like to display all items." << endl;
		cout << "Press 3 if you would like to remove all items." << endl;
		cout << "Press 4 if you would like to retrieve an item." << endl;
		cout << "Press 5 if you are finished modifying the list of items." << endl;
		cin >> choice;
		cin.ignore(50, '\n');
		if(choice == 1)
		{
			info.add_item();
		}
		if(choice == 2)
		{
			info.display();
		}
		if(choice == 3)
		{
			info.remove_all();
		}
		if(choice == 4)
		{
			cout << "Press 1 if you would like to retrieve a zoom room." << endl;
			cout << "Press 2 if you would like to retrieve a news station." << endl;
			cout << "Press 3 if you would like to retrieve a website." << endl;
			cin >> choice;
			cin.ignore(50, '\n');
			if(choice == 1)
			{
				chat = info.retrievez();
				cout << "Press 1 if you would like to change the zoom room." << endl;
				cout << "Press 2 if you would like to display the zoom room." << endl;
				cin >> choice;
				if(choice == 1)
				{
					cin >> chat;
				}
				if(choice == 2)
				{
					cout << chat;
				}
			}
			if(choice == 2)
			{
				station = info.retrieven();
				cout << "Press 1 if you would like to change the news station." << endl;
				cout << "Press 2 if you would like to display the news station." << endl;
				cin >> choice;
				if(choice == 1)
				{
					cin >> station;
				}
				if(choice == 2)
				{
					cout << station;
				}
			}
			if(choice == 3)
			{
				site = info.retrievew();
				cout << "Press 1 if you would like to change the website." << endl;
				cout << "Press 2 if you would like to display the website." << endl;
				cin >> choice;
				if(choice == 1)
				{
					cin >> site;
				}
				if(choice == 2)
				{
					cout << site;
				}
			}
		}
	}
	return 0;
}
