//Anteny Erdman
//CS202
//This file will be used to create the prototypes for all classes related to nodes

#include "material.h"

class node
{
	public:
		node();
		node(const node &original);
		~node();
		void connect_left(node * to_connect);
		void connect_right(node * to_connect);
		node* go_left();
		node* go_right();
		void create_zoom();
		void create_news();
		void create_web();
		char* get_name(int choice);
		void display();

	private:
		node * left;
		node * right;
		zoom * chat;
		news * station;
		website * site;
};


class list
{
	public:
		list();
		list(const list & original);
		~list();
		void add_item();
		void add_item(node * root, int choice);
		void remove_all();
		void remove_all(node * root);
		void display();
		void display(node * root);
		zoom& retrievez();
		zoom& retrievez(node * root, char * name);
		news& retrieven();
		news& retrieven(node * root, char * name);
		website& retrievew();
		website& retrievew(node * root, char * name);

	private:
		node * root;
};
