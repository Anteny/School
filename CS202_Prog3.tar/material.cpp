//Anteny Erdman
//CS202
//this file will be used to implement any members created in the material.h file

#include "node.h"

news::news()
{
}
news::news(const news &original): link(original)
{

}

char* news::get_name()
{
	if(title)
	{
		return title;
	}
	return NULL;
}

news & operator = (const news & original)
{
	if(this == &original)
	{
		return *this;
	}
	if(get_name())
	{
		delete [] title;
		delete [] des;
		delete [] source;
	}
	get_name() = new char [strlen(original.get_name()) + 1];
	strcpy(get_name(), original.get_name());
	des = new char [strlen(original.des) + 1];
	strcpy(des, original.des);
	source = new char [strlen(original.source) + 1];
	strcpy(source, original.source);
	priority = original.priority;
	return *this;
}

istream & operator >> (istream& in, news& n)
{
	char * temp = new char [1000];
	cout << "Please enter the name of the station." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000,'\n');
	if(n.get_name())
	{
		delete [] n.get_name();
	}
	n.get_name() = new char [strlen(temp) + 1];
	strcpy(n.get_name(), temp);
	cout << "Please enter a description of the station." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000, '\n');
	if(n.des)
	{
		delete [] n.des;
	}
	n.des = new char[strlen(temp) + 1];
	strcpy(n.des, temp);
	cout << "Please enter the reason for the station to be added." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000, '\n');
	if(n.source)
	{
		delete [] n.source;
	}
	n.source = new char [strlen(temp) + 1];
	strcpy(n.source, temp);
	cout << "Please enter the priority of the station as number." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000, '\n');
	in >> n.priority;
	return in;
}

ostream & operator << (ostream& out, const news& n)
{
	out << n.get_name() << " " << n.des << " " << n.source << " " << n.priority;
	return out;
} 

news operator + (const news &first)
{
	news temp;
	temp.get_name() = new char[strlen(first.get_name()) + 1];
	strcpy(temp.get_name(), first.get_name());
	strcat(temp.get_name(), get_name());
	temp.des = new char[strlen(first.des) + 1];
	strcpy(temp.des, first.des);
	strcat(temp.des, des);
	temp.source = new char[strlen(first.source) + 1];
	strcpy(temp.source, first.source);
	strcat(temp.source, source);
	if(first.priority > priority)
	{
		temp.priority = first.priority - priority;
	}
	else if(first.priority == priority)
	{
		temp.priority = first.priority;
	}
	else
	{
		temp.priority = priority - first.priority;
	}
	return temp;
}

news & operator += (const news & first, news & second)
{
	if(!second.get_name())
	{
		second.get_name() = new char[strlen(first.get_name()) + 1];
		strcpy(second.get_name(), first.get_name());
	}
	else
	{
		strcat(second.get_name(), first.get_name());
	}
	if(!second.des)
	{
		second.des = new char[strlen(first.des) + 1];
		strcpy(second.des, first.des);
	}
	else
	{
		strcat(second.des, first.des);
	}
	if(!second.source)
	{
		second.source = new char[strlen(first.source) + 1];
		strcpy(second.source, first.source);
	}
	else
	{
		strcat(second.source, first.source);
	}
	if(second.priority > first.priority)
	{
		second.priority = second.priority - first.priority;
	}
	else if(first.priority == second.priority)
	{
	}
	else
	{
		second.priority = first.priority - second.priority;
	}	
	return second;
}

bool operator == (const news & first, const news & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) == 0)
	{
		flag += 1;
	}
	if(first.priority == second.priority)
	{
		flag += 1;
	}
	if(flag == 4)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

bool operator != (const news & first, const news & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) == 0)
	{
		flag += 1;
	}
	if(first.priority == second.priority)
	{
		flag += 1;
	}
	if(flag == 4)
	{
		return false;
	}
	else 
	{
		return true;
	}
}

bool operator < (const news & first, const news & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) < 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) < 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) < 0)
	{
		flag += 1;
	}
	if(first.priority < second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
} 

bool operator <= (const news & first, const news & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) <= 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) <= 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) <= 0)
	{
		flag += 1;
	}
	if(first.priority <= second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

bool operator > (const news & first, const news & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) > 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) > 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) > 0)
	{
		flag += 1;
	}
	if(first.priority > second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

bool operator >= (const news & first, const news & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) >= 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) >= 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) >= 0)
	{
		flag += 1;
	}
	if(first.priority >= second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

zoom::zoom()
{

}

zoom::zoom(const zoom &original): link(original)
{

}

char* zoom::get_name()
{
	if(title)
	{
		return title;
	}
	return NULL;
}

zoom & operator = (const zoom &original)
{
	if(this == &original)
	{
		return *this;
	}
	if(get_name())
	{
		delete [] title;
		delete [] des;
		delete [] source;
	}
	get_name() = new char [original.get_name() + 1];
	strcpy(get_name(), original.get_name());
	des = new char [original.des + 1];
	strcpy(des, original.des);
	source = new char [original.source + 1];
	strcpy(source, original.source);
	priority = original.priority;
	return *this;
}

istream & operator >> (istream& in, zoom& z)
{
	char * temp = new char [1000];
	cout << "Please enter the name of the zoom room." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000,'\n');
	if(z.get_name())
	{
		delete [] z.get_name();
	}
	z.get_name() = new char [strlen(temp) + 1];
	strcpy(z.get_name(), temp);
	cout << "Please enter the description of the room." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000, '\n');
	if(z.des)
	{
		delete [] z.des;
	}
	z.des = new char[strlen(temp) + 1];
	strcpy(z.des, temp);
	cout << "Please enter the reason for the room to be created." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000, '\n');
	if(z.source)
	{
		delete [] z.source;
	}
	z.source = new char [strlen(temp) + 1];
	strcpy(z.source, temp);
	cout <<"Please enter the priority of the roomi as a number." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000, '\n');
	in >> z.priority;
	return in;
}

ostream & operator << (ostream& out, const zoom& z)
{
	out << z.get_name() << " " << z.des << " " << z.source << " " << z.priority;
	return out;
}

zoom operator + (const zoom &first)
{
	zoom temp;
	temp.get_name() = new char[strlen(first.get_name()) + 1];
	strcpy(temp.get_name(), first.get_name());
	strcat(temp.get_name(), get_name());
	temp.des = new char[strlen(first.des) + 1];
	strcpy(temp.des, first.des);
	strcat(temp.des, des);
	temp.source = new char[strlen(first.source) + 1];
	strcpy(temp.source, first.source);
	strcat(temp.source, source);
	if(first.priority > priority)
	{
		temp.priority = first.priority - priority;
	}
	else if(first.priority == priority)
	{
		temp.priority = first.priority;
	}
	else
	{
		temp.priority = priority - first.priority;
	}
	return temp;
}

zoom & operator += (const zoom & first, zoom & second)
{
	if(!second.get_name())
	{
		second.get_name() = new char[strlen(first.get_name()) + 1];
		strcpy(second.get_name(), first.get_name());
	}
	else
	{
		strcat(second.get_name(), first.get_name());
	}
	if(!second.des)
	{
		second.des = new char[strlen(first.des) + 1];
		strcpy(second.des, first.des);
	}
	else
	{
		strcat(second.des, first.des);
	}
	if(!second.source)
	{
		second.source = new char[strlen(first.source) + 1];
		strcpy(second.source, first.source);
	}
	else
	{
		strcat(second.source, first.source);
	}
	if(second.priority > first.priority)
	{
		second.priority = second.priority - first.priority;
	}
	else if(first.priority == second.priority)
	{
	}
	else
	{
		second.priority = first.priority - second.priority;
	}	
	return second;
}

bool operator == (const zoom & first, const zoom & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) == 0)
	{
		flag += 1;
	}
	if(first.priority == second.priority)
	{
		flag += 1;
	}
	if(flag == 4)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

bool operator != (const zoom & first, const zoom & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) == 0)
	{
		flag += 1;
	}
	if(first.priority == second.priority)
	{
		flag += 1;
	}
	if(flag == 4)
	{
		return false;
	}
	else 
	{
		return true;
	}
}

bool operator < (const zoom & first, const zoom & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) < 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) < 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) < 0)
	{
		flag += 1;
	}
	if(first.priority < second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
} 

bool operator <= (const zoom & first, const zoom & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) <= 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) <= 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) <= 0)
	{
		flag += 1;
	}
	if(first.priority <= second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

bool operator > (const zoom & first, const zoom & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) > 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) > 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) > 0)
	{
		flag += 1;
	}
	if(first.priority > second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

bool operator >= (const zoom & first, const zoom & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) >= 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) >= 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) >= 0)
	{
		flag += 1;
	}
	if(first.priority >= second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

website::website()
{

}

website::website(const website &original): link(original)
{

}

char* website::get_name()
{
	if(title)
	{
		return title;
	}
	return NULL;
}

website & operator = (const website &)
{
	if(this == &original)
	{
		return *this;
	}
	if(get_name())
	{
		delete [] title;
		delete [] des;
		delete [] source;
	}
	get_name() = new char [original.get_name() + 1];
	strcpy(get_name(), original.get_name());
	des = new char [original.des + 1];
	strcpy(des, original.des);
	source = new char [original.source + 1];
	strcpy(source, original.source);
	priority = original.priority;
	return *this;
}

istream & operator >> (istream& in, website& w)
{
	char * temp = new char [1000];
	cout << "Please enter the name of the website." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000,'\n');
	if(w.get_name())
	{
		delete [] w.get_name();
	}
	w.get_name() = new char [strlen(temp) + 1];
	strcpy(w.get_name(), temp);
	cout << "Please enter the description of the website." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000, '\n');
	if(w.des)
	{
		delete [] w.des;
	}
	w.des = new char[strlen(temp) + 1];
	strcpy(w.des, temp);
	cout << "Please enter the reason for the website being added." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000, '\n');
	if(w.source)
	{
		delete [] w.source;
	}
	w.source = new char [strlen(temp) + 1];
	strcpy(w.source, temp);
	cout << "Please enter the priority of the item as a number." << endl;
	in.get(temp, 1000, '\n');
	in.ignore(1000, '\n');
	in >> w.priority;
	return in;
}

ostream & operator << (ostream& out, const website& w)
{
	out << w.get_name() << " " << w.des << " " << w.source << " " << w.priority;
	return out;
}

website operator + (const website &first)
{
	website temp;
	temp.get_name() = new char[strlen(first.get_name()) + 1];
	strcpy(temp.get_name(), first.get_name());
	strcat(temp.get_name(), get_name());
	temp.des = new char[strlen(first.des) + 1];
	strcpy(temp.des, first.des);
	strcat(temp.des, des);
	temp.source = new char[strlen(first.source) + 1];
	strcpy(temp.source, first.source);
	strcat(temp.source, source);
	if(first.priority > priority)
	{
		temp.priority = first.priority - priority;
	}
	else if(first.priority == priority)
	{
		temp.priority = first.priority;
	}
	else
	{
		temp.priority = priority - first.priority;
	}
	return temp;
}

website & operator += (const website & first, website & second)
{
	if(!second.get_name())
	{
		second.get_name() = new char[strlen(first.get_name()) + 1];
		strcpy(second.get_name(), first.get_name());
	}
	else
	{
		strcat(second.get_name(), first.get_name());
	}
	if(!second.des)
	{
		second.des = new char[strlen(first.des) + 1];
		strcpy(second.des, first.des);
	}
	else
	{
		strcat(second.des, first.des);
	}
	if(second.source)
	{
		second.source = new char[strlen(first.source) + 1];
		strcpy(second.source, first.source);
	}
	else
	{
		strcat(second.source, first.source);
	}
	if(second.priority > first.priority)
	{
		second.priority = second.priority - first.priority;
	}
	else if(first.priority == second.priority)
	{
	}
	else
	{
		second.priority = first.priority - second.priority;
	}	
	return second;
}

bool operator == (const website & first, const website & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) == 0)
	{
		flag += 1;
	}
	if(first.priority == second.priority)
	{
		flag += 1;
	}
	if(flag == 4)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

bool operator != (const website & first, const website & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) == 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) == 0)
	{
		flag += 1;
	}
	if(first.priority == second.priority)
	{
		flag += 1;
	}
	if(flag == 4)
	{
		return false;
	}
	else 
	{
		return true;
	}
}

bool operator < (const website & first, const website & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) < 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) < 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) < 0)
	{
		flag += 1;
	}
	if(first.priority < second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
} 

bool operator <= (const website & first, const website & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) <= 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) <= 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) <= 0)
	{
		flag += 1;
	}
	if(first.priority <= second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

bool operator > (const website & first, const website & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) > 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) > 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) > 0)
	{
		flag += 1;
	}
	if(first.priority > second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

bool operator >= (const website & first, const website & second)
{
	int flag = 0;
	if(strcmp(first.get_name(), second.get_name()) >= 0)
	{
		flag += 1;
	}
	if(strcmp(first.des, second.des) >= 0)
	{
		flag += 1;
	}
	if(strcmp(first.source, second.source) >= 0)
	{
		flag += 1;
	}
	if(first.priority >= second.priority)
	{
		flag += 1;
	}
	if(flag >= 3)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

