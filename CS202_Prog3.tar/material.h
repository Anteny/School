//Anteny Erdman
//CS202
//This file will contain any prototypes about the different types of sources that will be used

#include "base.h"

class news: public link
{
	public:
		news();

		news(const news &original);

		news & operator = (const news &);

		char* get_name();

		friend istream & operator >> (istream&, news&);

		friend ostream & operator << (ostream&, const news&);

		news operator + (const news &first);

		news & operator += (const news & first);

		bool operator == (const news & first);

		bool operator != (const news & first);

		bool operator < (const news & first);

		bool operator <= (const news & first);

		bool operator > (const news & first);

		bool operator >= (const news & first);

};

class zoom: public link
{
	public:
		zoom();

		zoom(const zoom &original);

		zoom & operator = (const zoom &);

		char* get_name();

		friend istream & operator >> (istream&, zoom&);

		friend ostream & operator << (ostream&, const zoom&);

		zoom operator + (const zoom &first);

		zoom & operator += (const zoom & first);

		bool operator == (const zoom & first);

		bool operator != (const zoom & first);

		bool operator < (const zoom & first);

		bool operator <= (const zoom & first);

		bool operator > (const zoom & first);

		bool operator >= (const zoom & first);
};

class website: public link
{
	public:
		website();

		website(const website &original);

		website & operator = (const website &);

		char* get_name();

		friend istream & operator >> (istream&, website&);

		friend ostream & operator << (ostream&, const website&);

		website operator + (const website &first);

		website & operator += (const website & first);

		bool operator == (const website & first);

		bool operator != (const website & first);

		bool operator < (const website & first);

		bool operator <= (const website & first);

		bool operator > (const website & first);

		bool operator >= (const website & first);
};
