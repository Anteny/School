#include "func.h"

int checkIn(char input[], long var[])
{
    char *holder;
    int stop = 0;
    for(int i = 0; i < 15; ++i)
    {
	holder = input;
        if(*holder != '\n')
	{
	    var[i] = strtol(input, &holder, 0);
	    strcpy(input, holder);
	}
        else
	{
            stop = i;
            i = 15;
	}
    }
    if(stop == 0)
    {
        stop = 15;
    }
    return stop;
}   

void printM()
{
    char  *choices[] = {"Exit", "Addition", "Subtraction", "Multiplication", "Division", "Modulo", "Reverse Input"};
    for(int i = 0; i < 7; ++i)
    {
        printf("%i: %s\n", i, choices[i]);
    }
    return;
}

long add(long var[], int stop)
{
    long sum = var[0];
    for(int i = 1 ; i < stop; ++i)
    {
        sum += var[i];
    }
    return sum;
}

long sub(long var[], int stop)
{
    long dif = var[0];
    for(int i = 1 ; i < stop; ++i)
    {
        dif -= var[i];
    }
    return dif;
}

long mult(long var[], int stop)
{
    long total = var[0];
    for(int i = 1 ; i < stop; ++i)
    {
        total *= var[i];
    }
    return total;
}

float divide(long var[])
{
    float one = (float)var[0];
    float two = (float)var[1];
    return one/two;
}

long mod(long var[])
{
    return var[0]%var[1];
}

void rev(char input[])
{
    int i = strlen(input);
    while(i >= 0)
    {
        printf("%c", input[i]);
        --i;
    }
    printf("\n");
    return;
}
