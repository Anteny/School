#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

int checkIn(char input[], long var[]);

void printM();

long add(long var[], int stop);

long sub(long var[], int stop);

long mult(long var[], int stop);

float divide(long var[]);

long mod(long var[]);

void rev(char input[]);
