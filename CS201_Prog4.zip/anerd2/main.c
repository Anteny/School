#include "func.h"

int main()
{
    int stop = 0;
    int choice = 1;
    long var[15];
    char input[200];
    char temp[200];
    long result = 0;
    float fracRes = 0.0;
    printf("Please enter up to 15 numbers you would like to do arithmatic on.\n");
    fgets(input, sizeof(input), stdin);
    strcpy(temp, input);
    stop = checkIn(input, var);
    while(choice != 0)
    {
        printM();
        printf("Please enter which task you would like to perfom.\n");
        scanf("%d", &choice);
        while(choice < 0 || choice > 6)
        {
            printf("Invalid selection. Please try again.\n");
            printM();
	    scanf("%d", &choice);
        }
        switch(choice)
        {
            case 0 :
                return 0;
            case 1 :
                result = add(var, stop);
		printf("%li\n", result);
	        break;
            case 2 :
                result = sub(var, stop);
		printf("%li\n", result);
	        break;
            case 3 :
	        result = mult(var, stop);
		printf("%li\n", result);
	        break;
            case 4 :
		if(var[1] == 0)
		{
		    printf("NaN\n");
		    break;
		}
	        fracRes = divide(var);
		printf("%f\n", fracRes);
	        break;
            case 5 :
		if(var[1] == 0)
		{
		    printf("NaN\n");
		    break;
		}
	        result = mod(var);
		printf("%li\n", result);
	        break;
            case 6 :
	        rev(temp);
	        break;
        }
    }
}
