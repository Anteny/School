#include <stdio.h>

int checkNum(int choice);
