#include "setBits.h"


int main()
{
    int i = 0;
    int choice = 0;
    int bstring[16];
    //This will be the number whose bits are modified.
    unsigned short changed = 0;
    while(choice != -1)
    {
        printf("Please enter the number for the bit you want changed (0-15).");
	printf("\nPlease enter -1 if you dont want to enter another number.\n");
	scanf("%d", &choice);
	if(choice != -1)
	{
	    if(checkNum(choice))
	    {
	        changed |= 1 << choice;
	    }
	    else
	    {
		printf("That number is out of range aborting mission.\n");
		return 0;
	    }
	}
    }
    for(i = 0; i < 16; ++i)
    {
        bstring[i] = changed & 0x01;
        changed >>= 1;
    }
    for(i = 15; i >= 0; --i)
    {
        printf("%d", bstring[i]);
    }
    printf("\n");
    return 0;
}

int checkNum(int choice)
{
    if(choice >= 0 && choice <= 15)
    {
        return 1;
    }
    return 0;
}
