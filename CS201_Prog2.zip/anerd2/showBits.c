#include "showBits.h"

int main()
{
    unsigned int hex1 = 0;
    unsigned int hex2 = 0;
    unsigned int hex3 = 0;
    printf("Enter two hexadecimal numbers.\n");
    printf("Make sure they are seperated by a space and do not have the 0x.\n");
    scanf("%x %x", &hex1, &hex2);
    if(hex1 == 0 || hex2 == 0)
    {
        printf("Wrong amount of arguements inputed. Aborting.");
	return 0;
    }
    printf("Hex 1 and hex 2 have ");
    printSame(hex1, hex2, &hex3);
    printf(" as common bits set to 1.\n");
    printf("The resulting number is %X as a hexidecimal, ", hex3);
    printf("%d as a signed int, and a %u as an unsigned int. \n", hex3, hex3); 
    return 0;
}

void printSame(unsigned int hex1, unsigned int hex2, unsigned int *hex3)
{
    int count = 0;
    while(count < 32)
    {
        if((hex1 & (1<<count)) && (hex2 & (1<<count)))
	{
	    *hex3 |= 1 << count;
	    printf("%u,", count);
	}
	++count;
    }
    return;
}
