#include <stdio.h>

void printSame(unsigned int hex1, unsigned int hex2, unsigned int *hex3);
