//Anteny Erdman
//This program is used to calcultae an average GPA for a series of classes that is inputted by the user.
//It will also change the grade from a letter grade to a number grade.

#include <iostream>
using namespace std;

int main()
{
  char Grade = 0; //This variable will hold the grade that the user inputs.
  int Correct = 0; //This variable will control a loop that lets the user double check their choice of input in any situation.
  float Sum = 0; // This is the variable where the grade will be added to in number form. It will be divided by the class counter at the end.
  float NOC = 0; // This stands for number of classes and is going to be the counter for the classes taken.
  float OGPA = 0; // This variable is what will be calculated when dividing the sum by the number of classes.
  int WTimes = 0; // This variable will make it so that the first w wont count but all others will.
 
 do 
 {
   do // THis while loop lets the program run once and will repeat as long as the user enters an incorrect grade.
   {  
     cout << "Please enter a letter grade of A, B, C, D, F, W for withdraw, N for pass/no pass, or X." << endl;
     cin >> Grade;
     cout << "You entered " << Grade << " is that correct? 1 for yes. 2 for no." << endl;
     cin >> Correct;
   }while(Correct != 1);

   // The different if statements will bring the system to an area where each specific grade can get turned into a number and added to the sum while adding to the 
   // number of classes at the same time. it will then skip the rest of the if statements.  

   if(Grade == 65 || Grade == 97)
   {
     
     cout << "1 for A. 2 for A-." << endl;
     cin >> Correct; 
 
     if(Correct == 1)
     {
       Sum += 4.00;
       NOC += 1.00;
     }
 
     else
     {
       Sum += 3.67;
       NOC += 1.00;
     }
 
   }
 
   else if(Grade == 66 || Grade == 98)
   {
   
     cout << "1 for B+. 2 for B. 3 for B-" << endl;
     cin >> Correct;
 
     if(Correct == 1)
     {
       Sum += 3.34;
       NOC += 1.00;
     }
 
     else if(Correct == 2)
     {
       Sum += 3.00;
       NOC += 1.00;
     }	    
 
     else
     {
       Sum += 2.67;
       NOC += 1.00;
     }
     
   }
 
   else if(Grade == 67 || Grade == 99)
   {	  
   
     cout << "1 for C+. 2 For C. 3 for C-." << endl;
     cin >> Correct;
 
     if(Correct == 1)
     {
       Sum += 2.34;
       NOC += 1.00;
     }	    
 
     else if(Correct == 2)
     {
       Sum += 2.00;
       NOC += 1.00;      
     }	    
     
     else
     {
       Sum += 1.67;
       NOC += 1.00;
     }	    
 
   }
   else if(Grade == 68 || Grade == 100)
   {
    
     cout << "1 for D+. 2 for D. 3 for D-." << endl;
     cin >> Correct;
 
     if(Correct == 1)
     {
       Sum += 1.34;
       NOC += 1.00;
     }
 
     else if(Correct == 2)
     {
       Sum += 1.00;
       NOC += 1.00;
     }
 
     else
     {
       Sum += 0.67;
       NOC += 1.00;
     }
 
   }
   else if(Grade == 70 || Grade == 102)
   {
     NOC += 1.00;
   }
   else if(Grade == 87 || Grade == 119)
   {
     if(WTimes == 0)
     {
       WTimes += 1.00;
     }	    
     else
     {
       NOC += 1.00;
     }    
   }
  
   cout << "Do you have another grade to add? 1 for yes. 2 for no" << endl;
   cin >> Correct;
 }while(Correct == 1); 

 OGPA = Sum/NOC;
 cout << "Your overall GPA is " << OGPA << endl;	 

  return 0;
}
