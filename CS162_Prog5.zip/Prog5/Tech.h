//Anteny Erdman
//CS162
//This file will be used to hold the class prototype as well as
//any other headers I need.

#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

struct techItem
{
	char name[31];
	char des[201];
	char pro[201];
	char con[201];
	int cost;
	int rating;
};

int add(techItem items[], int count); //This will add another item that the user has.
void edit(char itemName[], techItem items[]); //This will allow the user to modify what was already written.
void displayAll(techItem items[], int count); //This will display all of the information about all of the items.
void displayPro(char itemName[], techItem items[]); //This will display the pro of the item the user selects.
void displayCon(char itemName[], techItem items[]); //This will display the con of the item the user selects.
void write(techItem items[], int count);
