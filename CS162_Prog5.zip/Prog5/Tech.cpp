//Anteny Erdman
//CS162
//This file will hold all of the functions that will be called by main.
#include "Tech.h"

const char outfile[] = "Techitems.txt";

//This will be used so that the user can add another item to the list.
int add(techItem items[], int count)
{

	char happy = 'n';
	cout << "This is tech item number " << count+1 << endl;
	cout << "Please enter the name of the item." << endl;
	cin.get(items[count].name, 31, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter a description of the item." << endl;
	cin.get(items[count].des, 201, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter a good thing about the item." << endl;
	cin.get(items[count].pro, 201, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter a bad thing about the item." << endl;
	cin.get(items[count].con, 201, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter the cost of the item in dollars using only integers." << endl;
	cin >> items[count].cost;
	cin.ignore(100, '\n');
	cout << "Please enter the number of stars you would give the item using only integers." << endl;
	cin >> items[count].rating;
	cin.ignore(100, '\n');
        count += 1;

	cout << "Would you like to enter another item? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100, '\n');
	if(happy == 'n' || happy == 'N')
	{
		count = -1;
	}
	return count;

}

//This function will be used to edit a specific item in the list.
void edit(char itemName[], techItem items[])
{
	int i = 0;
	while(strcmp(itemName, items[i].name) != 0)
	{
		i += 1;
	}
	cout << "Please enter the new name of the item." << endl;
	cin.get(items[i].name, 31, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter the new discription of the item." << endl;
	cin.get(items[i].des, 201, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter the new pro for the item." << endl;
	cin.get(items[i].pro, 201, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter the new con for the item." << endl;
	cin.get(items[i].con, 201, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter the new price for the item." << endl;
	cin >> items[i].cost;
	cin.ignore(100, '\n');
	cout << "Please enter the new rating for the item." << endl;
	cin >> items[i].rating;
	cin.ignore(100, '\n');

}

//This function will be used to display all of the items the userr has entered.
void displayAll(techItem items[], int count)
{
	int i = 0;
	while(i < count)
	{
		cout << "This is item " << i+1 << endl;
		cout << "The name of the item is " << items[i].name << endl;
		cout << items[i].des << endl;
		cout << "The pro of the item is " << items[i].pro << endl;
		cout << "The con of the item is " << items[i].con << endl;
		cout << "The cost of the item is $" << items[i].cost << endl;
		cout << "You gave the item the rating of " << items[i].rating << " stars." << endl;
		i += 1;
	}

}

//This function will display the Pro of a specific item.
void displayPro(char itemName[], techItem items[])
{
	int i = 0;
	while(strcmp(itemName, items[i].name) != 0)
	{
		i += 1;
	}
	cout << "The pro is:" << endl << items[i].pro << endl;
}

//This function will display the con of a specific item.
void displayCon(char itemName[], techItem items[])
{
	int i = 0;
	while(strcmp(itemName, items[i].name) != 0)
	{
		i += 1;
	}
	cout << "The con is:" << endl << items[i].con << endl;
}

//This function will save the items to an external file.
void write(techItem items[], int count)
{
	int i = 0;
	ofstream out;

	out.open(outfile, ios::app);

	if(out)
	{
		while(i < count)
		{
			out << "Item # " << i << endl;
			out << "Name:" << endl << items[i].name << endl;
			out << "Description:" << endl << items[i].des << endl;
			out << "Pro:" << endl << items[i].pro << endl;
			out << "Con:" << endl << items[i].con << endl;
			out << "Cost:" << endl << items[i].cost << endl;
			out << "Rating:" << endl << items[i].rating << endl;
			i += 1;
		}
		out.close();
		out.clear();
	}
}
