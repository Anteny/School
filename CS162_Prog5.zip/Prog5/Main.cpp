//Anteny Erdman
//CS162
//This file will house the main and send data to the functions in the Tech cpp file.
#include "Tech.h"


int main()
{
	int count = 0; // This will be used to traverse the array of structs created.
	int max = 0; // This will be used to set the length of the array dynamically.
	char happy = 'n'; //This will be used to allow the user options.
	int displayCount = 0; //This will be used to go through the array a second time without accessing any garbage
	char itemName[31];
	cout << "Please input how many items you would like to add to the list using only positive integers." << endl;
	cin >> max;
	cin.ignore(100, '\n');
	techItem * items = new techItem[max];

	//This section of the code will deal with adding items to the list.
	while(count < max && count >= 0)
	{
		count = add(items, count);
		if(count > 0)
		{
			displayCount = count;
			cout << displayCount << endl;
		}
		if(count <= 0)
		{
			displayCount += 1;
			cout << displayCount << endl;
		}
	}

	//This part of the code will allow the user to display all of the items they have entered.
	count = displayCount;
	cout << "Would you like to display everything you have entered? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100, '\n');
	if(happy == 'y' || happy == 'Y')
	{	
		displayAll(items, count);
	}

	//This part of the code will allow the user to display the pros and cons of a specific item they want.
	cout << "Would you like to display the pros and cons of an item of your choice? (Y/N)" << endl;
	cin >> happy; 
	cin.ignore(100, '\n');
	if(happy == 'y' || happy == 'Y')
	{
		cout << "Please enter the name of the item you would like to search." << endl;
		cin.get(itemName, 31, '\n');
		cin.ignore(100, '\n');
		displayPro(itemName, items);
		displayCon(itemName, items);
	}

	//This part of the code will deal with editing a specific item that the user chooses.
	cout << "would you like to edit one of the items you have entered? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100, '\n');
	if(happy == 'y' || happy == 'Y')
	{
		cout << "Please enter the name of the item that you would like to edit" << endl;
		cin.get(itemName, 31, '\n');
		cin.ignore(100, '\n');
		edit(itemName, items);
	}

	//This part of the code will deal with writing the file to an external data file.
	cout << "Would you like to save the data to an external data file? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100, '\n');
	if(happy == 'y' || happy == 'Y')
	{
		write(items, count);
	}
	return 0;
}
