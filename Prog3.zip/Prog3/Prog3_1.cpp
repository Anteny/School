#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

// Anteny Erdman
// This program will take in a user inputted phrase
// and will make several grammatical changes to that phrase.
// This will include checking the spacing, capitalization, and
// correct spelling of "the".

const int Size = 301;

void Space(char Array[]);
void Punctuation(char Array[]);
void The(char Array[]);
void Capital(char Array[]);
void Question(char Array[]);
void LonelyI(char Array[]);

// Main will be used to to send tasks to other funtions.
int main()
{
	char Phrase[Size];
	cout << "Please input a phrase to be corrected." << endl;
	cin.get(Phrase, Size, '\n');
	cin.ignore(200, '\n');
	
	//This will send the phrase to make sure there are no excess spaces.
	Space(Phrase);
	//This will send the phrase to make sure there is a space after punctuation.
  	Punctuation(Phrase);
	//This will send the phrase to make sure every the is spelled correctly.
	The(Phrase);
	//This will send the phrase to capitalize the first letter of a sentence.
	Capital(Phrase);
	//This will send the phrase to put a question mark at the end of a sentence that starts with does, or is.
	Question(Phrase);
	//This will send the phrase to capitalize any I's that are by themselves.
	LonelyI(Phrase);

	cout << Phrase << endl;

	return 0;
}

//This function will change lowercase i's into capitalized versions. This will only effect the pronoun i.
void LonelyI(char Phrase[])
{
	//This variable will be used to know the length of the phrase.
	int len = strlen(Phrase);
	//This variable will control a loop.
	int first = 0;
	
	for(first = 0; first < len; ++first)
	{
		if(Phrase[first] == ' ')
		{
			if(Phrase[first + 1] == 'i')
			{
				if(Phrase[first + 2] == ' ' || Phrase[first + 2] == '.' || Phrase[first + 2] == '?' || Phrase[first + 2] == '!')
				{
					Phrase[first + 1] = toupper(Phrase[first + 1]);
				}
			}
		}
	}
}


//This function will turn any sentance that starts with is, or does into a question.
void Question(char Phrase[])
{
	//This variable will let me know the length of the phrase.
	int len = strlen(Phrase);
	//This will control the loop.
	int first = 0;
	//This will control a second loop.
	int second = 0;
	//This will keep the code from changing all punctuation into question marks
	int happy = 0;
	
	for(first = 0; first < len; ++first)
	{
		if(Phrase[first] == 'I')
		{
			if(Phrase[first+1] == 's')
			{
				second = first;
				while(happy == 0)
				{
					if(Phrase[second] == '.' || Phrase[second] == '?' || Phrase[second] == '!')
					{
						Phrase[second] = '?';
						happy = 1;
					}
					second += 1;	
				}
			}
			happy = 0;
		}
		if(Phrase[first] == 'D')
		{
			if(Phrase[first+1] == 'o')
			{
				if(Phrase[first+2] == 'e')
				{
					if(Phrase[first+3] == 's')
					{
						second = first;
						while(happy == 0)
						{
							if(Phrase[second] == '.' || Phrase[second] == '?' || Phrase[second] == '!')
							{
								Phrase[second] = '?';
								happy = 1;
							}
							second += 1;
						}
					}
				}
			}
			happy = 0;
		}
	}
}


//This function will be used to capitalize the first letter of a sentence.
void Capital(char Phrase[])
{
	//This variable will let me know the length of the phrase
	int len = strlen(Phrase);
	//This variable will control the loop.
	int first = 0;

	//This will set the first letter of the phrase to a capital.
	Phrase[first] = toupper(Phrase[first]);
	
	for(first = 0; first < len; ++first)
	{
		if(Phrase[first] == '.' || Phrase[first] == '?' || Phrase[first] == '!')
		{
			Phrase[first+2] = toupper(Phrase[first+2]);
		}
	}
}


//This function will be used to correct any misspelled 'the's'.
void The(char Phrase[])
{
	//This variable will let me know the length of the phrase.
	int len = strlen(Phrase);
	//This variable will control the loop.
	int first = 0;

	for(first = 0; first < len; ++first)
	{
		if(Phrase[first] == 't' || Phrase[first] == 'h' || Phrase[first] == 'e')
		{
			if(Phrase[first+1] == 't' || Phrase[first+1] == 'h' || Phrase[first+1] == 'e')
			{
				if(Phrase[first+2] == 't' || Phrase[first+2] == 'h' || Phrase[first+2] == 'e')
				{
					Phrase[first] = 't';
					Phrase[first+1] = 'h';
					Phrase[first+2] = 'e';
				}
			}
		}
	}
}


//This function will make sure there is a space after puntuation.
void Punctuation(char Phrase[])
{
	//This variable will allow me to know how long the phrase is.
	int len = strlen(Phrase);
	//This variable will control the loop.
	int first = 0;
	//This variable will control a second loop.
	int second = 0;

	for(first = 0; first < len; ++first)
	{
		if(Phrase[first] == '.' || Phrase[first] == '?' || Phrase[first] == '!')
		{
			while(Phrase[first + 1] != ' ')
			{
				len += 1;
				for(second = len; second > first; --second)
				{
					Phrase[second + 1] = Phrase[second];
				}
			 	Phrase[first + 1] = ' ';
			}
		}
	}
}



// This function will remove any excess spaces in the phrase
void Space(char Phrase[])
{
	//This variable will let me know how long the phrase is.
	int len = strlen(Phrase);
        //This variable will control the first loop.
        int first = 0;	
	//This variable will control the second loop.
	int second = 0;
	

	for(first = 0; first < len; ++first)
	{
		if(Phrase[first] == ' ')
		{
			while(Phrase[first+1] == ' ')
			{
				//I wanted to create a second variable for this loop so that I didn't change what first was
				//this also allows me more control in how I control the loop.
				for(second = first; second < len-1; ++second)
				{
					Phrase[second] = Phrase[second+1];	
				}
				len = len - 1;
				Phrase[len] = '\0';
			}
		}
	}	

}
