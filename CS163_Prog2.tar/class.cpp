//Anteny Erdman
//CS163, Program 2
//This file is used for all of the functions that will be called by main.

#include "class.h"

//This is the constructor for the library class that will initilaze the data members inside it.
library::library()
{
	head = NULL;
}

//This is the destructor for the library class that will deallocate the memory library is using at the 
//end of the function.
library::~library()
{
	while(head)
	{
		if(head->next)
		{
			deck * temp = head->next;
			delete head;
			head = temp;
		}
		else
		{
			delete head;
			head = NULL;
		}
	}
}

//This function adds an item to the stack.
int library::push(int card)
{
	if(!head)
	{
		head = new deck;
		head->data = card;
		head->next = NULL;
		return 1;
	}
	deck * temp = new deck;
	temp->next = head;
	head = temp;
	head->data = card;
	return 1;
}

//This function removes an item from the stack.
int library::pop()
{
	int hold = 0;
	if(!head)
	{
		return 0;
	}
	deck * temp = head->next;
	hold = head->data;
	delete head;
	head = temp;
	return hold;
}

//This function is a waraper for the function that  will display everything that is in the stack.
int library::displayAll()
{
	return display_All(head);
}

//This function will diplay everything in the stack recursively
int library::display_All(deck * & head)
{
	if(!head)
	{
		return 0;
	}
	cout << head->data << endl;
	return display_All(head->next) +1;
}

//This will initilize the data for the queue class.
queue::queue()
{
	rear = NULL;
}

//This will deallocate the memory used by the queue class.
queue::~queue()
{	
	while(rear)
	{	
		winnings * temp = rear->future;
		rear->future = temp->future;
		delete temp;
		temp = NULL;
		if(rear->future == rear)
		{
			delete rear;
			rear = NULL;
		}
	}
}

//This will add an item to the queue.
int queue::enqueue(int card)
{
	if(!rear)
	{
		rear = new winnings;
		rear->future = rear;
		rear->item = card;
		return 1;
	}
	winnings * temp = new winnings;
	temp->future = rear->future;
	rear->future = temp;
	rear = temp;
	rear->item = card;
	return 1;
}

//This will check if there is another item in the queue.
int queue::peek()
{
	if(!rear)
	{
		return 0;
	}
	return rear->item;	
}

//This will remove an item from the queue.
int queue::dequeue()
{
	int hold = 0;
	if(!rear)
	{
		return 0;
	}
	if(rear->future == rear)
	{
		hold = rear->item;
		delete rear;
		rear = NULL;
		return hold;
	}
	winnings * temp = rear->future;
	rear->future = temp->future;
	hold = temp->item;
	delete temp;
	temp = NULL;
	return hold;
}

