//Anteny Erdman
//CS163 Program 2
//This file will house the main. The main will be responsible
//for dealing with the cards and using all of the functions
//set up in the class.cpp file.

#include "class.h"

int main()
{
	int variable = 0; //This variable is used to test if either players deck is empty. 
	library mylibrary; //This sets up the players library.
	library npclibrary; //This sets up the computers library.
	queue pcqueue; //This sets up the players winnings.
	queue npcqueue; //This sets up the computers winnings.
	queue thequeue; //This sets up the winnings that can't be determined.
	int count = 0; //This is used to end loops.
	int number = 0; //This is used for the randome number generator.
	srand(time(0));
	//This adds cards to the players library.
	while(count != 5)
	{
		number = (rand() % 11) + 2;
		mylibrary.push(number);
		++count;
	}
	count = 0;
	//This adds cards to the computers library.
	while(count!=5)
	{
		number = (rand() % 13) + 2;
		npclibrary.push(number);
		++count;
	}
	int pccard = 1; //This will be used to compare the cards.
	int npccard = 1; //This will be used to compare the cards.
	while(pccard && npccard)
	{
		cout << "Press enter to start the next round." << endl;
		cin.ignore(100, '\n');
		//This tells what the players card is.
		pccard = mylibrary.pop();
		if(pccard == 14)
		{
			cout << "Your card is an Ace!" << endl;
		}
		else if(pccard == 13)
		{ 
			cout << "Your card is a King!" << endl;
		}
		else if(pccard == 12)
		{
			cout << "Your card is a Queen!" << endl;
		}
		else if(pccard == 11)
		{
			cout << "Your card is a Jack!" << endl;
		}
		else
		{
			cout << "Your card is " << pccard << "!" << endl;
		}

		//This tells what the computers card is.
		npccard = npclibrary.pop();	
		if(npccard == 14)
		{
			cout << "The opponents card is an Ace!" << endl;
		}
		else if(npccard == 13)
		{ 
			cout << "The opponents card is a King!" << endl;
		}
		else if(npccard == 12)
		{
			cout << "The opponents card is a Queen!" << endl;
		}
		else if(npccard == 11)
		{
			cout << "The opponenets card is a Jack!" << endl;
		}
		else
		{
			cout << "The opponents card is " << npccard << "!" << endl;		
		}

		//This part is set up to send the cards to the computers queue if they won.
		if(pccard < npccard)
		{
			
			npcqueue.enqueue(pccard);
			npcqueue.enqueue(npccard);
			cout << "The opponent won the round!" << endl;
			while(thequeue.peek())
			{
				npcqueue.enqueue(thequeue.dequeue());
			}
		} 
		
		//This part is set up to send the cards to the players queue if they won.
		else if(pccard > npccard)
		{
			pcqueue.enqueue(pccard);
			pcqueue.enqueue(npccard);
			cout << "You won the round!" << endl;	
			while(thequeue.peek())
			{
				pcqueue.enqueue(thequeue.dequeue());
			}
		}
		else
		{
			//This part sets up the pot.
			cout << "It is war!" << endl;
			count = 0;	
			thequeue.enqueue(pccard);
			thequeue.enqueue(npccard);
			while(count != 3)
			{
				//This section will tell which of the computers cards where put into the pot.
				npccard = npclibrary.pop();
				if(npccard == 14)
				{
					cout << "An Ace was added to the winnings!" << endl;
				}
				else if(npccard == 13)
				{ 
					cout << "A King was added to the winnings!" << endl;
				}
				else if(npccard == 12)
				{
					cout << "A Queen was added to the winnings" << endl;
				}
				else if(npccard == 11)
				{
					cout << "A Jack was added to the winnings!" << endl;
				}
				else
				{
					cout << "A " <<  npccard << " has been added to the winnings!" << endl;
				}

				//This section will tell which of the players cards where put into the pot.
				pccard = mylibrary.pop();
				if(pccard == 14)
				{
					cout << "An Ace was added to the winnings!" << endl;
				}
				else if(pccard == 13)
				{ 
					cout << "A King was added to the winnings!" << endl;
				}
				else if(pccard == 12)
				{
					cout << "A Queen was added to the winnings" << endl;
				}
				else if(pccard == 11)
				{
					cout << "A Jack was added to the winnings!" << endl;
				}
				else
				{
					cout << "A " << pccard << " has been added to the winnings!" << endl;
				}
				//This puts both of the players cards into the pot.
				thequeue.enqueue(pccard);
				thequeue.enqueue(npccard);
				++count;
			}
		}
		//This section will be used to see if either player needs their winnings put into their library.
	        variable = npclibrary.pop();
		if(variable == 0)
		{
			while(npcqueue.peek())
			{
				variable = npcqueue.dequeue();
				npclibrary.push(variable);
			}
			cout << "The opponents winnnings have been added to their library!" << endl;
		}
		else
		{
			npclibrary.push(variable);
		}
		variable = mylibrary.pop();
		if(variable == 0)
		{
			while(pcqueue.peek())
			{
				variable = pcqueue.dequeue();
				mylibrary.push(variable);
			}
			cout << "Your winnings have been added to your library!" << endl;
		}
		else
		{
			mylibrary.push(variable);
		}
	}
	//This section will be used to see which player lost.
	if(npclibrary.pop() == 0)
	{
		cout << "The opponent lost." << endl;
		return 0;
	}
	if(mylibrary.pop() == 0)
	{
		cout << "You lost." << endl;
		return 0;
	}
	return 0;
}
