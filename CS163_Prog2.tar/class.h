//Anteny Erdman
//CS163, Program 2
//This file is to set up the classes and structs that
//will contain the prototypes fro the functions that main will
//use.

#include <cstdlib>
#include <iostream>
#include <ctime>
using namespace std;

//the deck struct will be used by the library.
struct deck
{
	int data = 0;
	deck * next;
};

//The winnings struct will be used by the queue class.
struct winnings
{
	int item = 0;
	winnings * future;
};

//The library class will be used to hold each players cards.
class library
{
	public:
		library();
		~library();
		int push(int card);
		int pop();
		int displayAll();
	private:
		int display_All(deck * & head);
		deck * head;
};

//Thie queue class will be used to hold the winnings of each round.
class queue
{
	public:
		queue();
		~queue();
		int dequeue();
		int enqueue(int card);
		int peek();
	private:
		winnings * rear;
};
