//Anteny Erdman
//CS202
//This file will be used to hold the node class prototypes.

#include "activities.h"

class node
{
	public:
		node();
		node(const node &original);
		~node();
		node* go_left();
		node* go_right();
		void connect_left(node* connect);
		void connect_right(node* connect);
		void add_item(general* to_add);
		void remove_item();
		void change();
		void display();
		void display_all();
		void change_other();

	private:
		node * left;
		node * right;
};

class list
{
	public:
		list();
		list(const list & original);
		~list();
		void add_item(int priority, general* to_add);
		void add_item(node * head, int priority, general* to_add);
		void remove_all();
		void remove_all(node * head);
		void display(int priority);
		void display(node * head, int priority);
		void display();
		void display(node * head);
		void change(int priority);
		void change(node * head, int priority);
		void change_other(int priority);
		void change_other(node * head, int priority);

	private:
		node * head;
};

