//Anteny Erdman
//CS202
//This file will be used to implement the node and base .h files.

#include "node.h"

general::general()
{
	title = NULL;
	time = NULL;
	priority = 0;
	independent = false;
}

general::general(const general &original): title(original.title), time(original.time), independent(original.independent)
{

}

general::~general()
{
	title = NULL;
	delete title;
	time = NULL;
	delete time;
}

node::node()
{
	left = NULL;
	right = NULL;
}

node::node(const node &original): left(original.left), right(original.right)
{

}

node::~node()
{
	left = NULL;
	right = NULL;
	delete left;
	delete right;
}

node* node::go_left()
{
	if(left)
	{
		return left;
	}
	else
	{
		return NULL;
	}
}

node* node::go_right()
{
	if(right)
	{
		return right;
	}
	else
	{
		return NULL;
	}
}

void node::connect_left(node* connect)
{
	left = connect;
	return;
}

void node::connect_right(node* connect)
{
	right = connect;
	return;
}
 
void node::add_item(general * to_add)
{
	return;
}

void node::remove_item()
{
	return;
}

void node::change()
{
	return;
}

void node::display()
{
}

void node::display_all()
{
	return;
}

void node::change_other()
{
	return;
}
		
list::list()
{
	head = NULL;
}

list::list(const list &original): head(original.head)
{

}

list::~list()
{
	
}

void list::add_item(int priority, general* to_add)
{
	if(!head)
	{
		head = new node;
	}
	return add_item(head, priority, to_add);
}

void list::add_item(node * head, int priority, general* to_add)
{
	return;
}

void list::remove_item(int priority)
{
	if(!head)
	{
		return;
	}
	return remove_item(head, priority);
}

void list::remove_item(node * head, int priority)
{
	return;
}

void list::display()
{
	if(!head)
	{
		return;
	}
	return display(head);
}

void list::display(node * head)
{
	return;
}

void list::display(int priority)
{
	if(!head)
	{
		return;
	}
	return display(head, priority);
}

void list::display(node * head, int priority)
{
	return;
}

void list::change(int priority)
{
	if(!head)
	{
		return;
	}
	return change(head, priority);
}

void list::change(node * head, int priority)
{
	return;
}

void list::change_other(int priority)
{
	if(!head)
	{
		return;
	}
	return change_other(head, priority);
}

void list::change_other(node * head, int priority)
{
	return;
}
