//Anteny Erdman
//CS202
//This file will be used to implement the classes and functions of activities.h

#include "node.h"

news::news()
{
	location = NULL;
}

news::news(const news & original): general(original), location(original.location)
{
}

news::~news()
{
	location = NULL;
	delete[] location;
}

void news::change_des()
{
	int size = 100;
	char * input = new char [size];
	cout << "How long will the run take?" << endl;
	cin.get(input, size, '\n');
	cin.ignore(size, '\n');
	des = new char[strlen(input) + 1];
	strcpy(des, input);
	input = NULL;
	delete[] input;
	return;
}

void news::change_title()
{
	int size = 100;
	char * input = new char [size];
	cout << "What is the run called?" << endl;
	cin.get(input, size, '\n');
	cin.ignore(size, '\n');
	title = new char[strlen(input) + 1];
	strcpy(title, input);
	input = NULL;
	delete[] input;
	return;
}

void news::what_location()
{
	int size = 100;
	char * input = new char [size];
	cout << "Where will you be running?" << endl;
	cin.get(input, size, '\n');
	cin.ignore(size, '\n');
	location = new char[strlen(input) + 1];
	strcpy(location, input);
	input = NULL;
	delete[] input;
	return;
}

void news::change_priority()
{
	cout << "What is the priority of the run? (lower numbers are higher priority. Minimum of 0.)" << endl;
	cin >> priority;
	cin.ignore(100, '\n');
	while(priority < 0)
	{
		cout << "The priority you entered was incorrect. Please enter a new priority." << endl;
		cin >> priority;
		cin.ignore(100, '\n');
	}
	return;
}

void news::change_source()
{
	cout << "Please press enter the amount of people going on the run. (Minimum of 1)" << endl;
	cin >> source;
	cin.ignore(100, '\n');
	return;
}

void news::display()
{
	cout << title << endl;
	cout << "The run will take " << des << endl;
	cout << "The run will take place at " << location << endl;
	if(source == 1)
	{ 
		cout << "This run will be done alone." << endl;
	}
	else 
	{
		cout << "This run will be done with " << source << " other people" << endl;
	}
	cout << "This run has a priority of " << priority << endl;
	return;
}

char* news::return_data()
{
	return title;
}

websites::websites()
{
	destination = NULL;
}

websites::websites(const websites & original): general(original), destination(original.destination)
{
}

websites::~websites()
{
	destination = NULL;
	delete[] destination;
}

void websites::change_des()
{
	int size = 100;
	char * input = new char [size];
	cout << "How long will the hike take?" << endl;
	cin.get(input, size, '\n');
	cin.ignore(size, '\n');
	des = new char[strlen(input) + 1];
	strcpy(des, input);
	input = NULL;
	delete[] input;
	return;
}

void websites::change_title()
{
	int size = 100;
	char * input = new char [size];
	cout << "What is the hike called?" << endl;
	cin.get(input, size, '\n');
	cin.ignore(size, '\n');
	title = new char[strlen(input) + 1];
	strcpy(title, input);
	input = NULL;
	delete[] input;
	return;
}

void websites::what_destination()
{
	int size = 100;
	char * input = new char [size];
	cout << "Where will you be hiking to?" << endl;
	cin.get(input, size, '\n');
	cin.ignore(size, '\n');
	destination = new char[strlen(input) + 1];
	strcpy(destination, input);
	input = NULL;
	delete[] input;
	return;
}

void websites::change_priority()
{
	cout << "What is the priority of the hike? (lower numbers are higher priority. Minimum of 0.)" << endl;
	cin >> priority;
	cin.ignore(100, '\n');
	while(priority < 0)
	{
		cout << "The priority you entered was incorrect. Please enter a new priority." << endl;
		cin >> priority;
		cin.ignore(100, '\n');
	}
	return;
}

void websites::change_source()
{
	cout << "Please press enter the amount of people going on the hike. (Minimum of 1)" << endl;
	cin >> source;
	cin.ignore(100, '\n');
	return;
}

void websites::display()
{
	cout << title << endl;
	cout << "The hike will take " << des << endl;
	cout << "The hike will go to " << destination << endl;
	if(source == 1)
	{ 
		cout << "This hike will be done alone." << endl;
	}
	else 
	{
		cout << "This hike will be done with " << source << " other people" << endl;
	}
	cout << "This hike has a priority of " << priority << endl;
	return;
}

char* websites::return_data()
{
	return title;
}

zoom::zoom()
{
	spot = NULL;
}

zoom::zoom(const zoom & original): general(original), spot(original.spot)
{
}

zoom::~zoom()
{
	spot = NULL;
	delete[] spot;
}

void zoom::change_des()
{
	int size = 100;
	char * input = new char [size];
	cout << "How long will the swim be?" << endl;
	cin.get(input, size, '\n');
	cin.ignore(size, '\n');
	des = new char[strlen(input) + 1];
	strcpy(des, input);
	input = NULL;
	delete[] input;
	return;
}

void zoom::change_title()
{
	int size = 100;
	char * input = new char [size];
	cout << "What is the name of the swim?" << endl;
	cin.get(input, size, '\n');
	cin.ignore(size, '\n');
	title = new char[strlen(input) + 1];
	strcpy(title, input);
	input = NULL;
	delete[] input;
	return;
}

void zoom::what_spot()
{
	int size = 100;
	char * input = new char [size];
	cout << "Where will you be zoom?" << endl;
	cin.get(input, size, '\n');
	cin.ignore(size, '\n');
	spot = new char[strlen(input) + 1];
	strcpy(spot, input);
	input = NULL;
	delete[] input;
	return;
}

void zoom::change_priority()
{
	cout << "What is the priority of the swim? (lower numbers are higher priority. Minimum of 0.)" << endl;
	cin >> priority;
	cin.ignore(100, '\n');
	while(priority < 0)
	{
		cout << "The priority you entered was incorrect. Please enter a new priority." << endl;
		cin >> priority;
		cin.ignore(100, '\n');
	}
	return;
}

void zoom::change_source()
{
	cout << "Please press enter the amount of people going zoom. (Minimum of 1)" << endl;
	cin >> source;
	cin.ignore(100, '\n');
	return;
}

void zoom::display()
{
	cout << title << endl;
	cout << "The swim will take " << des << endl;
	cout << "The swim will take place at " << spot << endl;
	if(source == 1)
	{ 
		cout << "This swim will be done alone." << endl;
	}
	else 
	{
		cout << "This swim will be done with " << source << " other people" << endl;
	}
	cout << "This swim has a priority of " << priority << endl;
	return;
}

char* zoom::return_data()
{
	return title;
}
