//Anteny Erdman
//CS202
//This file will be used for main, which will use all the functions.

#include "node.h"

int main()
{
	return 0;
}
