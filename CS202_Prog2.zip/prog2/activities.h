//Anteny Erdman
//CS202
//This file will be used for the constructors of all the activities derived from general

#include "base.h"

class news: public general
{
	public:
		news();
		news(const news &original);
		~news();
		void change_des();
		void change_title();
		void change_priority();
		void change_source();
		void what_location();
		void display();
		char* return_data();

	private:
		char * location;
};

class websites: public general
{
	public:
		websites();
		websites(const websites &original);
		~websites();
		void change_des();
		void change_title();
		void change_priority();
		void change_source();
		void what_destination();
		void display();
		char* return_data();

	private:
		char * destination;
};

class zoom: public general
{
	public:
		zoom();
		zoom(const zoom &original);
		~zoom();
		void change_des();
		void change_title();
		void change_priority();
		void change_source();
		void what_spot();
		void display();
		char* return_data();

	private:
		char * spot;
};
