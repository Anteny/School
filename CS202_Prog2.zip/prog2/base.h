//Anteny Erdman
//CS202
//This file will be used for the base class constructor.

#include <iostream>
#include <cstring>
using namespace std;

class general
{
	public:
		general();
		general(const general &original);
		~general();

	protected:
		char * title;
		char * des;
		int priority;
		char * source;
};		
