//Anteny Erdman
//CS162
//This file will be used to implement all functions otehr then the main for my program.
//This will include making the linear linked list, letting the user edit items in the list
//and displaying parts or wholes of the list.

#include "list.h"
const char outfile[] = "Tech_Items.txt";
//This function will allow the user to make a choice
int choice()
{
	char happy = 'n';
	cin >> happy;
	cin.ignore(100, '\n');
	while(happy != 'y' && happy != 'Y' && happy != 'n' && happy != 'N')
	{
		cout << "Your have entered an invalid response. Please respond with Y or N." << endl;
		cin >> happy;
		cin.ignore(100, '\n');
	}

	if(happy == 'y' || happy == 'Y')
		return 1;
	if(happy == 'n' || happy == 'N')
		return 0;
}

//This function will start creeating the linked list.
void create(node * head)
{
	int happy = 1;
	node * current = head;
	cout << "Please enter the name of the item." << endl;
	cin.get(current->name, 50, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter the description of the item." << endl;
	cin.get(current->des, 200, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter a good thing about the item." << endl;
	cin.get(current->pro, 200, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter a bad thing about the item." << endl;
	cin.get(current->con, 200, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter the cost of the item using only positive integers." << endl;
	cin >> current->cost;
	cin.ignore(100, '\n');
	cout << "Please enter the rating of the item using only positive integers." << endl;
	cin >> current->rating;
	cin.ignore(100,'\n');
	cout << "Would you like to enter another item? (Y/N)" << endl;
	happy = choice();
	while(happy == 1)
	{
		add(head, current);
		cout << "Would you like to enter another item? (Y/N)" << endl;
		happy = choice();
	}
}

//this fucntion will continue to add in another element into the list when its called.
void add(node * head, node * current)
{
	current->next = new node;
	current = current-> next;
	cout << "Please enter the name of the item." << endl;
	cin.get(current->name, 50, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter the description of the item." << endl;
	cin.get(current->des, 200, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter a good thing about the item." << endl;
	cin.get(current->pro, 200, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter a bad thing about the item." << endl;
	cin.get(current->con, 200, '\n');
	cin.ignore(100, '\n');
	cout << "Please enter the cost of the item using only positive integers." << endl;
	cin >> current->cost;
	cin.ignore(100, '\n');
	cout << "Please enter the rating of the item using only positive integers." << endl;
	cin >> current->rating;
	cin.ignore(100, '\n');
}

//this function will be used to display all of the data entered.
void displayAll(node*head)
{

	node * current = head;
	while(current)
	{
		cout << "Name: " << current->name << endl;
		cout << "Description: " << current->des << endl;
		cout << "Pro: " << current->pro << endl;
		cout << "Con: " << current->con << endl;
		cout << "The item costs $" << current->cost << endl;
		cout << "You gave the item a rating of " << current->rating << " stars" << endl << endl;
		current = current->next;
	}

}

//this function will display the pro of an item.
void displayPro(node * head, char match[])
{
	node * current = head;
	while(strcmp(current->name, match) !=0 && current != NULL)
	{
		current = current->next;
	}
	if(strcmp(current->name, match) == 0)
	{
		cout << current->pro << endl;
	}
}

//This fuction will display the con of an item.
void displayCon(node * head, char match[])
{
	node * current = head;
	while(strcmp(current->name, match) != 0 && current != NULL)
	{
		current = current->next;
	}
	if(strcmp(current->name, match) == 0)
	{
		cout << current->con << endl;
	}
}

//This function will allow the user to edit an item.
void edit(node * head, char match[])
{
	node * current = head;
	while(strcmp(current->name, match) != 0 && current != NULL)
	{
		current = current->next;
	}
	if(strcmp(current->name, match) == 0)
	{
		cout << "Please enter the new name of the item." << endl;
		cin.get(current->name, 50, '\n');
		cin.ignore(100, '\n');
		cout << "Please enter the new description of the item." << endl;
		cin.get(current->des, 200, '\n');
		cin.ignore(100, '\n');
		cout << "Please enter a good thing about the item." << endl;
		cin.get(current->pro, 200,'\n');
		cin.ignore(100, '\n');
		cout << "Please enter a bad thing about the item." << endl;
		cin.get(current->con, 200, '\n');
		cin.ignore(100, '\n');
		cout << "Please enter the new cost in positive integers." << endl;
		cin >> current->cost;
		cin.ignore(100, '\n');
		cout << "Please enter the new rating of the item." << endl;
		cin >> current->rating; 
		cin.ignore(100, '\n');
	}
}

//This function will allow the user to write the data to an exernal file.
void write(node * head)
{
	node * current = head;
	ofstream out;
	out.open(outfile, ios::app);
	if(out)
	{
		while(current)
		{
			out << "Name: " << current->name << endl;
			out << "Description: " << current->des << endl;
			out << "Pro: " << current->pro << endl;
			out << "Con: " << current->con << endl;
			out << "The item costs $" << current->cost << endl;
			out << "The rating is " << current->rating << " stars" << endl << endl;
			current = current->next;
		}
		out.close();
		out.clear();
	}
}
