//Anteny Erdman
//CS162
//This file will hold the main that will delegate tasks to the functions in the list.cpp file.

#include "list.h"

int main()
{
	node * head = new node;
	int happy = 1;
	char match [51];

	//this will create the list
	create(head);

	//This will let the user display all the content
	cout << "Would you like to display everything that you have entered? (Y/N)" << endl;	
	happy = choice();
	if(happy == 1)
		displayAll(head);

	//This will let the user display the pro of their choosing
	cout << "Would you like to display the pro of an item? (Y/N)" << endl;
	happy = choice();
	if(happy ==1)
	{
		cout << "Please enter the name of the item you would like to display the pro for." << endl;
		cin.get(match, 50, '\n');
		cin.ignore(100, '\n');
		displayPro(head, match);
	}

	//This will let the user display only a con of their choosing
	cout << "Would you like to display the con of an item? (Y/N)" << endl;
	happy = choice();
	if(happy == 1)
	{
		cout << "Please enter the name of the item you would like to diplay the con for." << endl;
		cin.get(match, 50, '\n');
		cin.ignore(100, '\n');
		displayCon(head, match);
	}

	//This section will allow the user to choose to edit an item
	cout << "Would you like to edit an item? (Y/N)" << endl;
	happy = choice();
	if(happy == 1)
	{
		cout << "Please enter the name of the item you would like to edit." << endl;
		cin.get(match, 50, '\n');
		cin.ignore(100, '\n');
		edit(head, match);
	}

	//This section will have the user to write the content to an external file
	cout << "Would you like to save the data to an external file? (Y/N)" << endl;
	happy = choice();
	if(happy == 1)
		write(head);

	return 0;
}
