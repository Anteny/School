//Anteny Erdman
//CS162
//This file will hold the structure that will be used as a linear linked list as well as all of
//the prototypes for functions that I will be using.

#include <iostream>
#include <cstring>
#include <cctype>
#include <fstream>
using namespace std;
//This is the bases of each element of the list.
struct node
{
	char name[51];
	char des[201];
	int cost;
	char pro[201];
	char con[201];
	int rating;
	node * next;
};

//This function will allow the user to make a choice
int choice();

//This function will be used to add in another item to the list.
void add(node * head, node * current);

//This function will be used to create the linear linked list.
void create(node * head);

//This function will allow the user to edit a member of the list.
void edit(node * head, char match[]);

//This will display all of the items in the list.
void displayAll(node * head);

//This will display the pro of one item in the list.
void displayPro(node * head, char match[]);

//This will display the con of one item in the list.
void displayCon(node * head, char match[]);

//This will write the data to an external data file.
void write(node * head);
