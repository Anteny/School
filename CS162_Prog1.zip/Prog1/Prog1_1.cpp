//Anteny Erdman
//This code is used as pracitce to get me familiar to the linux system

#include <iostream>
using namespace std;

int main()
{
	cout << "Welcome to computer science!" << endl;
	
	return 0;
}
