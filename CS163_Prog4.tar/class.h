//Anteny Erdman
//CS163
//This file will contain all of the prototypes and data types that will be used
//in all other parts of this program

#include <iostream>
#include <cctype>
#include <cstring>

using namespace std;

//this struct will be inside each part of the tree so that it can hold the movies
//each character has been in.
struct films
{
	char ** titles = new char*[10];
	films * next;
};

//This struct is used for each node in a tree.
struct tree
{
	char * name;
	films * head;
	tree * left;
	tree * right;
};

//This class will contain all of the functions that will be used on the tree at
//any given point in time
class fun
{
	public:
		fun();
		~fun();
		int add(char * name, char * title);
		char ** search(char * name);
		int remove(char * name, char * title);
		int display_char(char * name);
		int display_all();
		int get_height();
		int is_efficient();
	private:
		tree * root;
		int add(char * name, char * title, tree * &root);
		char ** search(char * name, tree * root);
		int remove(char * name, char * title, tree * &root, tree * &behind);
		int display_char(char * name, tree * root);
		int display_all(tree * root);
		int get_height(tree * root);
		int is_efficient(tree * root);	
};
