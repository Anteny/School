//Anteny Erdman
//CS163
//This file will contain all of the functions used in the program
//as well as the constructor and destructor.

#include "class.h"

//This is the constructor.
fun::fun()
{
	root = NULL;
}

//This function is the destructor
fun::~fun()
{
	tree * nullify = NULL;
	tree * temp = root;
	while(temp)
	{
		if(temp->left)
		{
			if(!temp->left->left && !temp->left->right)
			{
				nullify = temp;
				temp = temp->left;
				nullify->left = NULL;
			}
			else
			{
				temp = temp->left;
			}
		}
		else if(temp->right)
		{
			if(!temp->right->left && !temp->right->right)
			{
				nullify = temp;
				temp = temp->left;
				nullify->right = NULL;
			}
			else
			{
				temp = temp->right;
			}
		}
		else
		{
			films * hold = temp->head;
			while(temp->head->next)
			{
				hold = temp->head;
				for(int i = 0; i < 10; ++i)
				{
					delete hold->titles[i];
				}
				temp->head = hold->next;
				delete hold;
			}
			if(temp->head)
			{
				for(int i = 0; i < 10; ++i)
				{
					delete hold->titles[i];
				}
				delete temp->head;
				temp->head = NULL;
				hold = NULL;
			}
			delete temp;
			temp = root;
		}
	}
}

//This is a wrapper function for the add function.
int fun::add(char * name, char * title)
{
	return add(name, title, root);
}

//Tjis function will be used to dd a new character and or movie to the list.
int fun::add(char * name, char * title, tree * &root)
{
	int i = 0;
	if(!root)
	{
		root = new tree;
		root->left = NULL;
		root->right = NULL;
		root->head = new films;
		films * temp = root->head;
		temp->next = NULL;
		for(int i = 0; i < 10; ++i)
		{
			temp->titles[i] = NULL;
		}
		temp->titles[0] = new char[(strlen(title) + 1)];
		strcpy(temp->titles[0], title);
		root->name = new char[(strlen(name) + 1)];
		strcpy(root->name, name);
		return 1;
	}	
	if(root->name == NULL)
	{
		
		root->head = new films;
		films * temp = root->head;
		temp->next = NULL;
		for(int i = 0; i < 10; ++i)
		{
			temp->titles[i] = NULL;
		}
		temp->titles[0] = new char[(strlen(title) + 1)];
		strcpy(temp->titles[0], title);
		root->name = new char[(strlen(name) + 1)];
		strcpy(root->name, name);
		return 1;
	}
	if(strcmp(root->name, name) == 0)
	{
		films * temp = root->head;
		while(temp->next)
		{
			temp = temp->next;
		}
		while(temp->titles[i])
		{
			++i;
		}
		temp->titles[i] = new char[(strlen(title) + 1)];
		strcpy(temp->titles[i], title);
		if(i == 10)
		{
			temp->next = new films;
			temp = temp->next;
			temp->next = NULL;
			for(int i = 0; i < 10; ++i)
			{
				temp->titles[i] = NULL;
			}
		}
		return 1;
	}	
	if(strcmp(root->name, name) > 0)
	{
		if(root->left == NULL)
		{
			root->left = new tree;
			root->left->name = NULL;
			root->left->right = NULL;
			root->left->left = NULL;
			root->left->head = NULL;
		}
		return add(name, title, root->left);
	}
	if(strcmp(root->name, name) < 0)
	{
		if(root->right == NULL)
		{
			root->right = new tree;	
			root->right->name = NULL;
			root->right->right = NULL;
			root->right->left = NULL;
			root->right->head = NULL;
		}
		return add(name, title, root->right);
	}
	return 0;
}

//This function will be used as a wrapper function to search for a character.
char** fun::search(char * name)
{
	if(!root)
	{
		return NULL;
	}
	return search(name, root);
}

//This function will be used to recursively search for a character
char** fun::search(char * name, tree * root)
{
	if(!root)
	{
		return NULL;
	}	
	if(strcmp(root->name, name) == 0)
	{
		int total = 0;
		int loc = 0;
		films * temp = root->head;
		while(temp->next)
		{
			temp = temp->next;	
			total += 10;
		}
		while(temp->titles[loc])
		{
			++total;
			++loc;
		}
		loc = 0;
		temp = root->head;
		char ** results = new char*[total];
		while(total > 0)
		{
			results[total] = new char[(strlen(temp->titles[loc]) + 1)];
			strcpy(results[total], temp->titles[loc]);
			--total;
			++loc;
			if(loc == 11)
			{
				temp = temp->next;
				loc = 0;
			}
		}
		return results;
	}
	if(strcmp(root->name, name) > 0)
	{
		return search(name, root->left);
	}
	if(strcmp(root->name, name) < 0)
	{
		return search(name, root->right);
	}
	return NULL;
}

//This function will be used as a wrapper function for the remove function.
int fun::remove(char * name, char * title)
{
	int flag = 0;
	if(!root)
	{
		return 0;
	}
	int results = remove(name, title, root, root);
	if(results == 1)
	{
		return 1;
	}
	else if(results == 2)
	{
		return 0;
	}
	else
	{
		tree * backup = root;
		tree * temp = root;
		while(strcmp(temp->name, name) != 0)
		{
			if(strcmp(temp->name, name) > 0)
			{
				backup = temp;
				temp = temp->left;
			}
			if(strcmp(temp->name, name) < 0)
			{
				backup = temp;
				temp = temp->right;
			}
		}
		films * hold = temp->head;
		while(hold)
		{
			for(int i = 0; i < 10; ++ i)
			{
				if(strcmp(title, hold->titles[i]) == 0)
				{
					delete hold->titles[i];
					hold->titles[i] = NULL;
					flag = 1;
				}
			}
			hold = hold->next;
		}
		hold = temp->head;
		if(flag == 1)
		{
			if(hold->titles[0] == NULL)
			{
				tree * search = temp->right;
				tree * follow = temp;
				while(search->left)
				{
					follow = search;
					search = search->left;
				}
				if(search->right)
				{
					follow->left = search->right;
				}
				else
				{
					follow->left = NULL;
				}	
				if(backup == temp)
				{
					root = search;
					search->right = temp->right;
					search->left = temp->left;
					delete [] temp->head->titles;
					delete temp->head;
					delete temp->name;
					delete temp;
				}
				if(backup->right == temp)
				{
					backup->right = search;
					search->right = temp->right;
					search->left = temp->left;
					delete [] temp->head->titles;
					delete temp->head;
					delete temp->name;
					delete temp;
				}
				if(backup->left == temp)
				{
					backup->left = search;
					search->right = temp->right;
					search->left = temp->left;
					delete [] temp->head->titles;
					delete temp->head;
					delete temp->name;
					delete temp;
				}
			}
		}
		return 1;
	}
}

//This function is used to recursively remove a character.
int fun::remove(char * name, char * title, tree * &root, tree * &behind)
{
	int flag = 0;
	if(!root)
	{
		return 0;
	}
	if(strcmp(root->name, name) > 0)
	{
		return remove(name, title, root->left, root);
	}
	if(strcmp(root->name, name) < 0)
	{
		return remove(name, title, root->right, root);
	}
	if(strcmp(root->name, name) == 0)
	{	
		films * hold = root->head;	
		for(int i = 0; i < 10; ++ i)
		{
			if(hold->titles[i] != NULL)
			{
				if(strcmp(title, hold->titles[i]) == 0)
				{
					delete [] hold->titles[i];
					hold->titles[i] = NULL;
					if(root->left && root->right)
					{
						return 2;
					}
					flag = 1;
				}
			}
		}
		while(hold->next)
		{
			hold = hold->next;
			for(int i = 0; i < 10; ++ i)
			{
				if(hold->titles[i] != NULL)
				{
					if(strcmp(title, hold->titles[i]) == 0)
					{
						delete [] hold->titles[i];
						hold->titles[i] = NULL;
						if(root->left && root->right)
						{
							return 2;
						}
						flag = 1;
					}
				}
			}
		}
		hold = root->head;
		if(flag == 1)
		{
			if(hold->titles[0] == NULL)
			{	
				if(root == behind)
				{
					if((root->left == NULL) && (root->right == NULL))
					{
						delete [] root->head->titles;
						delete root->head;
						delete root->name;
						delete root;
						root = NULL;
						return 1;
					}
					if(root->right == NULL)
					{
						behind = root->left;	
						delete [] root->head->titles;
						delete root->head;
						delete root->name;
						delete root;
						root = behind;
						return 1;
					}
				}

				if(root->right == NULL)
				{
					if(behind->right == root)
					{
						behind->right = root->left;
					}
					if(behind->left == root)
					{
						behind->left = root->left;
					}
					delete [] root->head->titles;
					delete root->head;
					delete root->name;
					delete root;
					return 1;
				}
				if(root->left == NULL)
				{
					if(behind->right == root)
					{
						behind->right = root->right;
					}
					if(behind->left == root)
					{
						behind->left = root->right;
					}
					delete [] root->head->titles;
					delete root->head;
					delete root->name;
					delete root;
					return 1;
				}
				if((root->left == NULL) && (root->right == NULL))
				{
					delete [] root->head->titles;
					delete root->head;
					delete root->name;
					delete root;
					return 1;
				}
				
			}
		}		
	}
	return 0;
}

//This function will be a wrapper function for the display character function.
int fun::display_char(char * name)
{
	if(!root)
	{
		return 0;
	}
	return display_char(name, root);
}

//Thid function will be used to display all films that a character has been apart of.
int fun::display_char(char * name, tree * root)
{
	if(!root)
	{
		return 0;
	}
	if(strcmp(root->name, name) > 0)
	{
		return display_char(name, root);
	}
	if(strcmp(root->name, name) < 0)
	{
		return display_char(name, root);
	}
	if(strcmp(root->name, name) == 0)
	{
		films * temp = root->head;
		for(int i = 0; i < 10; ++i)
		{
			if(temp->titles[i] != NULL)
			{
				cout << temp->titles[i] << endl;
			}
		}
		while(temp->next)
		{
			temp = temp->next;
			for(int i = 0; i < 10; ++i)
			{
				if(temp->titles[i] != NULL)
				{
					cout << temp->titles[i] << endl;
				}
			}
		}
		return 1;
	}
	return 0;
}

//This function will be the wrapper function for the display_all function
int fun::display_all()
{
	if(!root)
	{
		return 0;
	}
	return display_all(root);
}

//This function will display every character and their movies.
int fun::display_all(tree * root)
{
	int count = 0;
	if(!root)
	{
		return 0;
	}
	count += display_all(root->left);
	cout << root->name << " has been in these movies:" << endl;	
	films * temp = root->head;
	for(int i = 0; i < 10; ++i)
	{
		if(temp->titles[i] != NULL)
		{
			cout << temp->titles[i] << endl;	
		}
	}
	while(temp->next)
	{
		temp = temp->next;
		for(int i = 0; i < 10; ++i)
		{
			if(temp->titles[i] != NULL)
			{
				cout << temp->titles[i] << endl;
			}
		}
	}
	count += display_all(root->right);
	return count + 1;
}

//This function will be a wrapper fo the get height function
int fun::get_height()
{
	if(!root)
	{
		return 0;
	}
	return get_height(root);
}

//This function will be used to get the height of the tree.
int fun::get_height(tree * root)
{
	if(!root)
	{
		return 0;
	}
	int count_l = 0;
	int count_r = 0;
	count_l += get_height(root->left);
	count_r += get_height(root->right);
	if(count_l >= count_r)
	{
		return count_l + 1;
	}
	else
	{
		return count_r + 1;
	}
}

//This function will be used as a wrapper function for the is_efficient function
int fun::is_efficient()
{
	if(!root)
	{
		return 1;
	}
	int balance = is_efficient(root);
	if(balance < -1 || balance > 1)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

//This function will be used to make sure that the tree created is efficient.
int fun::is_efficient(tree * root)
{
	if(!root)
	{
		return 0;
	}
	int count_l = 0;
	int count_r = 0;
	count_l += is_efficient(root->left);
	count_r += is_efficient(root->right);
	return (count_l - count_r) + 1;
}
