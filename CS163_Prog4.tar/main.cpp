//Anteny Erdman
//CS163
//This file will contain the main function that will be used to call all of the functions
//created in the class.cpp file.

#include "class.h"

int main()
{
	fun my_char;
	//happy controls if the user wants to do another action
	char happy = 'Y';
	//choice controls what function the user calls.
	int choice = 0;
	//The success will allow me to use and catch the variables from the functions
	int success = 0;
	//name and title are used to store what the user wants to add to the list
	char * name = new char[100];
	char * title = new char[100];
	while(happy == 'Y' || happy == 'y')
	{
		//this section will sho wthe user the choices that they get to make.
		cout << "Please enter 1. to add a character and a film, or to add a film to a character already in the list." << endl;
		cout << "Please enter 2. to search for a character." << endl;
		cout << "Please enter 3. to remove a film from a character, and then remove the character if their list of films is empty." << endl;
		cout << "Please enter 4. to display a specific character and their films." << endl;
		cout << "Please enter 5. to display all characters and their films." << endl;
		cout << "For testers/developers enter 6. to get the longest path of the data." << endl;
		cout << "For testers/developers enter 7. to see if the data is balanced." << endl;
		cin >> choice;
		cin.ignore(100, '\n');
		//This first choice will have the user add a character or film to the list
		if(choice == 1)
		{
			cout << "What is the name of the character?" << endl;
			cin.get(name, 100, '\n');
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				name[i] = tolower(name[i]);
			}
			cout << "What is the name of the film that the character is in?" << endl;
			cin.get(title, 100, '\n');
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				title[i] = tolower(title[i]);
			}
			success = my_char.add(name, title);
			if(success == 0)
			{
				cout << "The character or film couldn't be added." << endl;
			}
		}

		//This second choice will have the user search for a character
		if(choice == 2)
		{	
			cout << "What is the name of the character?" << endl;
			cin.get(name, 100, '\n');
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				name[i] = tolower(name[i]);
			}
			char ** results = my_char.search(name);
			if(!results)
			{
				cout << "The character couldn't be found." << endl;
			}
			else 
			{
				cout << "The character was found." << endl;
			}
		}

		//This third choice will allow the users to remove a film from a characters list and then remove the character if they have no more films.
		if(choice == 3)
		{
			cout << "What is the name of the character?" << endl;
			cin.get(name, 100, '\n');
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				name[i] = tolower(name[i]);
			}
			cout << "What is the name of the film that the character is in?" << endl;
			cin.get(title, 100, '\n');
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				title[i] = tolower(title[i]);
			}
			success = my_char.remove(name, title);
			if(success == 0)
			{
				cout << "The character couldn't be removed." << endl;
			}
			else
			{
				cout << "The character was removed." << endl;
			}
		}

		//This fourth choice will allow the user to display a specific character and their movies.
		if(choice == 4)
		{
			cout << "What is the name of the character?" << endl;
			cin.get(name, 100, '\n');
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				name[i] = tolower(name[i]);
			}
			success = my_char.display_char(name);
			if(success == 0)
			{
				cout << "The character couldn't be displayed." << endl;
			}
		}

		//This fifth choice will allow the user to display all characters and their films.
		if(choice == 5)
		{
			success = my_char.display_all();
			if(success == 0)
			{
				cout << "The characters couldn't be displayed" << endl;
			}
		}
		
		//The sixth choice will allow the user to see the height of the tree
		if(choice == 6)
		{
			success = my_char.get_height();
			cout << "The height is " << success << "." << endl;
		}

		//The seventh choice will allow the user to see if the tree is efficient
		if(choice == 7)
		{
			success = my_char.is_efficient();
			if(success == 1)
			{
				cout << "The data is balanced." << endl;
			}
			else
			{
				cout << "The data is not balanced." << endl;
			}
		}
		cout << "Would you like to make another action? (Y/N)" << endl;
		cin >> happy;
		cin.ignore(100, '\n');
	}
	return 0;
}
