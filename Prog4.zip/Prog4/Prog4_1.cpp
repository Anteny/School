//Anteny Erdman
//CS 162
//This program will is made so that the user can have a way to document what they need for
//spring break as well as asking them several other peices of information that will help to procure the object.


#include <iostream>
#include <cstring>
using namespace std;

//This struct will hold all the info for the item the user needs
struct item
{
	//This array will hold the name of what the user needs.
	char name[31];
	//This variable will hold the description of the item needed.
	char des[151];
	//This variable will hold the price the item will cost.
	int cost;
	//this variable will hold the numerical amount of time it will take to get the item.
	int time;
	//This variable will hold the quantity of the item needed.
	int quantity;
	//This variable will hold what help the user needs to get the item.
	char help[151];
};

//This function will read in an item and the other information relating to it.
int read(item thing[]);
//This function will allow the user to call the information from an item.
void display(item thing[], int count);
//This function will search for an item that has already been made.
void search(item thing[], int count);


//This function will send tasks to other functions.
int main()
{


	//This will create an array of 10 items.
	item thing[10];
	//This will allow the user to make decisions.
	char happy = 'N';
	//This will be used to know how many items were inputted.
	int count = 0;

	//this section of code will send the user to the read function.
	count = read(thing);

	//This section of code will ask if the user wants to search and display an item they have inputted.
	cout << "Would you like to search for and display an item? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100,'\n');
	if(happy == 'Y' || happy == 'y')
	{
		search(thing, count);
	}

	//This section of code will ask if the user wants to display all of the items they have inputted.
	cout << "Would you like to display everything? (Y/N)" << endl;
	cin >> happy;
	cin.ignore(100,'\n');
	if(happy == 'Y' || happy == 'y')
	{
		display(thing, count);
	}


	return 0;
}

//This function will be used to read in any item from the user.
int read(item thing[])
{
	//This will be used to control if the user wants more items.
	char happy = 'n';
	//This will be used to control how many items are in inputted.
	int i = 0;
	//this will be used to know how many items were inputted
	int count = 0;
	do
	{
		if(i > 9)
		{
			cout << "You have put in the max amount of items." << endl;
			i = 15;
		}
		else
		{
			cout << "What is the name of the activity or item for spring break?" << endl;
			cin.get(thing[i].name, 31, '\n');
			cin.ignore(100, '\n');
			cout << "Describe the item that the activity you are planning will need." << endl;
			cin.get(thing[i].des, 151, '\n'); 
			cin.ignore(100, '\n');
			cout << "Please input the cost of the item or activity." << endl;
			cin >> thing[i].cost;
			cin.ignore(100, '\n');
			cout << "Please input the number of days it will take to get the item." << endl;
			cin >> thing[i].time;
			cin.ignore(100, '\n');
			cout << "PLease enter the number of items you would like." << endl;
			cin >> thing[i].quantity;
			cin.ignore(100, '\n');
			cout << "PLease explain any help that you will need to obtain the item." << endl;
			cin.get(thing[i].help, 151, '\n');
			cin.ignore(100, '\n');
			cout << "Would you like to input another item. (Y/N)" << endl;
			cin >> happy;
			cin.ignore(100,'\n');
			count +=1;
			if(happy == 'n' || happy == 'N')
			{
				i = 11;
			}
			else
			{
				++i;
			}
		}
	}while(i < 11);
	return count;
}

//This function will search for an item or activity and display it.
void search(item thing[], int count)
{
	//This will be used so the user can search through the array.
	char find[31];
	//this will be used to contol loops.
	int i = 0;

	cout << "Please input the exact same name as the item you are searching for." << endl;
	cin.get(find, 31, '\n');
	cin.ignore(100, '\n');
	do
	{
		if(strcmp(find, thing[i].name) == 0)
		{
			cout << "Name of item/activity: " << thing[i].name << endl;
			cout << "Description: " << thing[i].des << endl;
			cout << "Cost: $" << thing[i].cost << endl;
			cout << "Time: " << thing[i].time << " days" << endl;
			cout << "Quantity: " << thing[i].quantity << " items" << endl;
			cout << "Help: " << thing[i].help << endl;	
		}
		++i;
	}while(i < count);

}
//This function will display all the items the user has inputted.
void display(item thing[], int count)
{	
	//This will control counters.
	int i = 0;

	do
	{
		cout << "Name of item/activity: " << thing[i].name << endl;
		cout << "Description: " << thing[i].des << endl;
		cout << "Cost: $" << thing[i].cost << endl;
		cout << "Time: " << thing[i].time << " days" << endl;
		cout << "Quatity: " << thing[i].quantity << " items" << endl;
		cout << "Help: " << thing[i].help << endl;
		i += 1;
	}while(i < count);
}

