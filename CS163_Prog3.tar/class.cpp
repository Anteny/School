//Anteny Erdman
//CS163
//This file will contain all of the functions that main will call.
//It will also have any extra functions I decide to add to it.

#include "class.h"
//This function will initiate the data.
Hash::Hash()
{
	char_table = new person*[79];
	act_table = new person*[101];
	for(int i = 0; i < 101; ++ i)
	{
		act_table[i] = NULL;
	}
	for(int i = 0; i < 79; ++ i)
	{
		char_table[i] = NULL;
	}
}
//This function will release all of the memory that was dynamically allocated.
Hash::~Hash()
{
	for(int i = 0; i < 101; ++ i)
	{
		if(act_table[i])
		{
			if(act_table[i]->beggining)
			{
				list * temp = act_table[i]->beggining;
				while(temp->future)
				{
					temp = temp->future;
					delete [] act_table[i]->beggining->title;
					delete act_table[i]->beggining;
					act_table[i]->beggining = temp;
				}
				delete [] act_table[i]->beggining->title;
				delete act_table[i]->beggining;
				temp = NULL;
				act_table[i]->beggining = NULL;
			}
			person * hold = act_table[i];
			while(hold->next)
			{
				hold = hold->next;
				delete [] act_table[i]->id;
				delete act_table[i];
				act_table[i] = hold;
			}
			delete [] hold->id;
			delete hold;
			hold = NULL;
			act_table[i] = NULL;
		}
	}
	for(int i = 0; i < 79; ++ i)
	{
		if(char_table[i])
		{
			if(char_table[i]->beggining)
			{
				list * temp = char_table[i]->beggining;
				while(temp->future)
				{
					temp = temp->future;
					delete [] char_table[i]->beggining->title;
					delete char_table[i]->beggining;
					char_table[i]->beggining = temp;
				}
				delete [] char_table[i]->beggining->title;
				delete char_table[i]->beggining;
				temp = NULL;
				char_table[i]->beggining = NULL;
			}
			person * hold = char_table[i];
			while(hold->next)
			{
				hold = hold->next;
				delete [] char_table[i]->id;
				delete char_table[i];
				char_table[i] = hold;
			}
			delete [] hold->id;
			delete hold;
			hold = NULL;
			char_table[i] = NULL;
		}
	}
}

//This function will hash the name of the person.
int Hash::hash_function(char * name, int size)
{
	int length = strlen(name);
	int sum = 0;
	for(int i = 0; i < length; ++ i)
	{
		sum += name[i];
	}
	sum = (sum % size);
	return sum;
}

//This function will add a character
int Hash::add_char(char * name, char * title)
{
	person * temp = NULL;
	int length_a = strlen(name);
	int length_b = strlen(title);
	int key = hash_function(name, 79);
	if(char_table[key] == NULL)
	{
		char_table[key] = new person;
		temp = char_table[key];
		temp->id = new char[length_a + 1];
		strcpy(temp->id, name);
		temp->beggining = new list;
		temp->beggining->title = new char[length_b + 1];
		temp->beggining->future = NULL;
		strcpy(temp->beggining->title, title);
		return 1;
	}
	temp = char_table[key];
	while(temp)
	{
		if(strcmp(name, temp->id) == 0)
		{
			list * hold = temp->beggining;
			temp->beggining = new list;
			temp->beggining->future = hold;
			temp->beggining->title = new char[length_b + 1];
			strcpy(temp->beggining->title, title);
			return 1;
		}
		temp = temp->next;
	}
	return 0;
}

//This function will allow the usser to add an actor
int Hash::add_act(char * name, char * title)
{
	person * temp = NULL;
	int length_a = strlen(name);
	int length_b = strlen(title);
	int key = hash_function(name, 101);
	if(act_table[key] == NULL)
	{
		act_table[key] = new person;
		temp = act_table[key];
		temp->id = new char[length_a + 1];
		strcpy(temp->id, name);
		temp->beggining = new list;
		temp->beggining->title = new char[length_b + 1];
		strcpy(temp->beggining->title, title);
		return 1;
	}
	temp = act_table[key];
	while(temp)
	{
		if(strcmp(name, temp->id) == 0)
		{
			list * hold = temp->beggining;
			temp->beggining = new list;
			temp->beggining->future = hold;
			temp->beggining->title = new char[length_b + 1];
			strcpy(temp->beggining->title, title);
			return 1;
		}
		temp = temp->next;
	}
	return 0;
}

//this function will be a wrapper function for the recursive search character function.
list* Hash::search_char(char * name)
{
	int key = hash_function(name, 79);
	if(char_table[key] == NULL)
	{
		return NULL;
	}
	return search_char(name, char_table[key]);
}

//this function will be used to search for a character recursivly.
list* Hash::search_char(char * name, person * head)
{
	if(!head)
	{
		return NULL;
	}
	if(strcmp(name, head->id) == 0)
	{
		return head->beggining;
	}
	return search_char(name, head->next);
}

//This function will be used to search for an actor.
list* Hash::search_act(char * name)
{
	int key = hash_function(name, 101);
	if(act_table[key] == NULL)
	{
		return NULL;
	}
	return search_act(name, act_table[key]);
}

//This function will be used to recursivly seach for an actors films.
list* Hash::search_act(char * name, person * head)
{
	if(!head)
	{
		return NULL;
	}
	if(strcmp(name, head->id) == 0)
	{
		return head->beggining;
	}
	return search_act(name, head->next);
}

//This function will be used to remove certain characters.
int Hash::remove(char * name)
{
	int key = hash_function(name, 79);
	if(char_table[key] == NULL)
	{
		return 0;
	}
	person * temp = char_table[key];
	while(temp != NULL)
	{
		if(strcmp(name, temp->id) == 0)
		{
			while(temp->beggining->future != NULL)
			{
				list * hold = temp->beggining->future;
				delete [] temp->beggining->title;
				delete temp->beggining;
				temp->beggining = hold;
			}
			delete [] temp->beggining->title;
			delete temp->beggining;
			temp->beggining = NULL;
			delete [] temp->id;
			delete temp;
			temp = NULL;
			char_table[key] = NULL;
			return 1;
		}
		temp = temp->next;
	}
	return 0;
}

//This function will be used to display everything.
int Hash::display_char(char * name)
{	
	int key = hash_function(name, 79);
	if(char_table[key] == NULL)
	{
		return 0;
	}
	person * temp = char_table[key];
	while(temp != NULL)
	{
		if(strcmp(name, temp->id) == 0)
		{
			while(temp->beggining)
			{
				cout << temp->beggining->title << endl;
				temp->beggining = temp->beggining->future;
			}
			return 1;
		}
		temp = temp->next;
	}
	return 0;
}

//This function will display all items
int Hash::display_all()
{
	for(int i = 0; i < 79; ++ i)
	{
		if(char_table[i])
		{
			cout << char_table[i]->id  << " is in the following movies: " << endl;
			list * temp = char_table[i]->beggining;
			while(temp)
			{
				cout << temp->title << endl;
				temp = temp->future;
			}
		}
	}
	for(int i = 0; i < 101; ++ i)
	{
		if(act_table[i])
		{
			cout << act_table[i]->id  << " is in the following movies: " << endl;
			list * temp = act_table[i]->beggining;
			while(temp)
			{
				cout << temp->title << endl;
				temp = temp->future;
			}
		}
	}
	return 1;
}
	
//This function will be used to read in the data from an external file.
int Hash::read(char * name, char * title)
{
	ifstream in_file;
	in_file.open("Films.txt");
	if(in_file)
	{
		in_file.get(title, 100, '\n');
		while(in_file && !in_file.eof())
		{
			in_file.ignore(100, '\n');
			in_file.get(name, 100, '\n');
			add_char(name, title);
			in_file.ignore(100, '\n');
			in_file.get(name, 100, '\n');
			add_act(name, title);
			in_file.get(title, 100, '\n');
		}
		in_file.close();
		in_file.clear();
		return 1;
	}
	return 0;
}

