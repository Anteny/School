//Anteny Erdman
//CS 163
//This file will contain the main function that will be used as a menu
//to access the functions in the class.cpp file.

#include "class.h"

int main()
{
	//this will be used to store the films name.
	char title[100];
	//this will be used to store the name of a person.
	char name[100];
	Hash films;
	char happy = 'Y';
	int choice = 0;
	//This will read in the data from the file so that the program can have data set beforehand.
	int success = films.read(name, title);
	if(success == 0)
	{
		cout << "the list is starting empty." << endl;
	}
	else
	{
		cout << "the list is starting with items in it." << endl;
	}

	//The while statement and couts will act as a menu allowing the user to choose what they would like to do.
	while(happy == 'Y' || happy == 'y')
	{
		cout << "If you would like to add a movie please press 1." << endl;
		cout << "If you would like to search by character please press 2." << endl;
		cout << "If you would like to search by actor please press 3." << endl;
		cout << "If you would like to remove by character please press 4." << endl;
		cout << "If you would like to display by character please press 5." << endl;
		cout << "If you would like to display all please press 6." << endl;
		cin >> choice;
		cin.ignore(100, '\n');

		//This if statement will allow the user to add the characters and actors to the lists.
		if(choice == 1)
		{
			cout << "What is the name of the movie?" << endl;
			cin.get(title, 100);
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				title[i] = tolower(title[i]);
			}
			cout << "How many characters are in the movie?" << endl;
			cin >> choice;
			cin.ignore(100, '\n');
			for(int i = 0; i < choice; ++i)
			{
				cout << "What is the name of a character?" << endl;
				cin.get(name, 100);
				cin.ignore(100, '\n');
				for(int i = 0; i < 100; ++i)
				{
					name[i] = tolower(name[i]);
				}
				success = films.add_char(name, title);
				if(success == 0)
				{
					cout << "The character couldn't be added." << endl;
				}
			}
			cout << "How many actors are in the movie?" << endl;
			cin >> choice;
			cin.ignore(100, '\n');
			for(int i = 0; i < choice; ++i)
			{
				cout << "What is the name of an actor?" << endl;
				cin.get(name, 100);
				cin.ignore(100, '\n');
				for(int i = 0; i < 100; ++i)
				{
					name[i] = tolower(name[i]);
				}
				success = films.add_act(name, title);
				if(success == 0)
				{
					cout << "The actor couldn't be added." << endl;
				}
			}	
		}
		//This statement allows the user to search for movies that a character was in.
		if(choice == 2)
		{
			cout << "What is the name of the character?" << endl;
			cin.get(name, 100);
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				name[i] = tolower(name[i]);
			}
			list * head = films.search_char(name);
			if(!head)
			{
				cout << "The character couldn't be found." << endl;
			}
			else
			{
				while(head)
				{
					cout << head->title << endl;
					head = head->future;
				}
				cout << "These are all of the movies this character has been in." << endl;
			}
		}
		//This statement allows the user to search for any film an actor was in.
		if(choice == 3)
		{
			cout << "What is the name of the actor?" << endl;
			cin.get(name, 100);
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				name[i] = tolower(name[i]);
			}
			list * head = films.search_act(name);
			if(!head)
			{
				cout << "The actor couldn't be found." << endl;
			}
			else
			{
				while(head)
				{
					cout << head->title << endl;
					head = head->future;
				}
				cout << "These are all of the movies the actor has been in." << endl;
			}
		}
		//This choice allows the user to remove characters and their movies from the list.
		if(choice == 4)
		{
			cout << "What is the name of the character you would like to remove?" << endl;
			cin.get(name, 100);
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				name[i] = tolower(name[i]);
			}
			success = films.remove(name);
			if(success == 0)
			{
				cout << "The character couldn't be removed." << endl;
			}
			else
			{
				cout << "The character was removed." << endl;
			}
		}
		//This statement allows the users to display by character.
		if(choice == 5)
		{
			cout << "What is the name of the character you would like to display?" << endl;
			cin.get(name, 100);
			cin.ignore(100, '\n');
			for(int i = 0; i < 100; ++i)
			{
				name[i] = tolower(name[i]);
			}
			success = films.display_char(name);
			if(success == 0)
			{
				cout << "The character couldn't be displayed" << endl;
			}
		}
		//This statement allows the user to display everything.
		if(choice == 6)
		{
			success = films.display_all();
			if(success == 0)
			{
				cout << "There are no movies." << endl;
			}
		}

		cout << "Would you like to do something else? (Y/N)" << endl;
		cin >> happy;
		cin.ignore(100, '\n');
	}
	return 0;
}
