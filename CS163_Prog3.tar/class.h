// Anteny Erdman
// CS163
// This file will be used to hold the class and structs that
// will be used for the rest of the program. It will also contain
// the prototypes for that will be used.

#include <iostream>
#include <cstring>
#include <cctype>
#include <fstream>
using namespace std;

struct list
{
	char * title;
	list * future;
};

struct person
{
	char * id;
	person * next;
	list * beggining;
};

class Hash
{
	public:
		Hash();
		~Hash();
		int add_char(char * name, char * title);
		int add_act(char * name, char * title);
		list* search_char(char * name);
		list* search_act(char * name);
		int remove(char * name);
		int display_char(char * name);
		int display_all();
		int read(char * name, char * title);
	private:
		int hash_function(char * name, int size);
		list* search_char(char * name, person * head);
		list* search_act(char * name, person * head);
		person ** char_table;
		person ** act_table;
};
